# Strikepoint — turn the game into an Android app (GitHub)

1. Create a GitHub repo, upload **everything in this folder** (keep `.github/workflows/android.yml`).
2. Host the multiplayer server (Render / Railway): build `npm install`, start `npm start`. It serves the game and the rooms.
3. Edit `server-config.js` and put your server address, e.g. `window.STRIKEPOINT_SERVER = 'strikepoint.onrender.com';` and commit.
4. GitHub → **Actions → Build Android APK** (runs automatically on every push). When green, open the run → **Artifacts → Strikepoint-APK** → install `app-debug.apk` on your phone (allow "install unknown apps").

## Squad roles (multiplayer)
- Tap **ROLE** (top-left) to choose RIFLEMAN / SNIPER / COMMANDER. Only one sniper and one commander per room.
- **Sniper:** CLIMB TO PERCH puts you on the tall tower with a scope (SCOPE button = zoom). You can free-look and shoot from the top.
- **Commander:** a dot appears over every teammate. Tap a dot to select, then **SNIPER TRACK** — the sniper's scope locks on that teammate automatically and reports hostiles within 30 m (✔ clear / ⚠ count shown on the dot).
- **TACTICAL MAP:** tap the ground to set a waypoint, then press HOLD / ADVANCE / FLANK / COVER / REGROUP. Everyone sees the order and a gold beacon. COVER with a teammate selected sends the sniper to cover him.

## Play on your own Wi-Fi (no Render, PC + phones together)
1. Install Node.js (nodejs.org) on the PC. Double-click **START_PC_SERVER.bat** (Windows) or run `./start-server.sh` (Mac/Linux).
2. The window prints addresses like `http://192.168.1.20:3000`. On the PC open `http://localhost:3000`.
3. Phones on the same Wi-Fi open that 192.168… address in Chrome, **or** in the Android app type `192.168.1.20:3000` in the Server box.
4. One player taps MULTIPLAYER → CREATE ROOM, others enter the 4-letter code. PC and phone players share the same room.
If phones can't connect, allow Node.js through Windows Firewall (Private networks) when Windows asks.

## PC controls
WASD move · mouse look (click to capture) · left click fire · R reload · Space jump · C crouch · E enter car · V camera · Esc release mouse.
Squad: **O** role · **P** sniper perch · **M** tactical map · **N** next teammate · **T** sniper track · **1-5** tactics.

## v13: bigger arena + more hostiles
- Arena is now **220 x 220 m** (was 140 x 140): the old town is the centre, surrounded by a ring road, 4 corner outposts with lookout towers, 8 villages (each with a tall building for the sniper) and 8 more vehicles.
- Co-op hostiles scale with the room: **7 per player when the host presses START** (2 players = 14 ... 5 players = 35). Solo play stays at 20.
- Tuning: arena size = `HALF` in `world.js`; solo count = the `20` in `spawnEnemies()` (game.js); per-player count = the `7` and cap `35` in `server.js`.

## v14: LAN GAME (Blur-style, no setup)
- **PC:** double-click `START_PC_SERVER.bat` (or `./start-server.sh`). The game opens in your browser and the **LAN room is created automatically**. Press START MISSION when your friends have joined.
- **Phone (app):** tap **LAN GAME · AUTO WI-FI**. The app searches the Wi-Fi for the PC and joins the same room by itself. First search can take up to ~20 s; the last PC is remembered so the next time is instant.
- **Phone (browser, no app):** open the address shown in the lobby (e.g. `http://192.168.1.20:3000`) and tap LAN.
- Works with any mix of PCs and phones, up to 5 per room; a 6th player automatically gets a second room.
- Needs the PC and phones on the same Wi-Fi, and Windows Firewall must allow Node.js on private networks (Windows asks the first time).
- Set `NO_BROWSER=1` to stop the PC server opening the browser.

## If the GitHub build fails — checklist
1. **Upload the CONTENTS of the folder, not the folder itself.** In your repo the first things you see must be `package.json`, `game.js`, `capacitor.config.json` and the `.github` folder. If everything sits inside a sub-folder, GitHub will not run the build.
2. **The workflow file must exist** at `.github/workflows/android.yml`. If the `.github` folder did not upload (hidden folders are sometimes skipped): in GitHub choose *Add file → Create new file*, type `.github/workflows/android.yml` as the name and paste the contents of `android.yml`.
3. Open **Actions → Build Android APK → the red run → the red step**. The step name tells you where it stopped; send me that step's last lines.
4. Download: Actions → the run → **Strikepoint-APK** (or the **Releases** page → `Strikepoint.apk`).

## v16: graphics
- **Pause menu → GRAPHICS:** AUTO (default, lowers itself on slow devices) · LOW · MEDIUM · HIGH · ULTRA. ULTRA = sharper/bigger shadows, full pixel density, longer view distance (PC or strong phones).
- HIGH and ULTRA add sky-lit reflections on cars, weapons and metal, a sun glow, drifting dust and a soft vignette. MEDIUM keeps the sun glow and vignette; LOW is the fastest.
- **FPS COUNTER** (pause menu) shows the frame rate so you can pick the best level for your phone.
- Commander orders are now also spoken aloud to the squad ("Commander: Flank").

## v17: tested fixes
- Role button now skips roles another player already holds (previously a second player could not become COMMANDER once someone was SNIPER).
- Squad buttons are grouped at the top right so they no longer cover the game controls; the tactical map no longer hides them.
- Sniper perch: the rifle model and tower deck are hidden from the sniper's own camera so the view over the arena is clear.

## Uploading from a phone (no folder upload needed)
Upload ONLY two things to the repo: this zip file, and the workflow file `.github/workflows/android.yml` (create it with *Add file → Create new file* and paste `android.yml`). The workflow unzips the game by itself on GitHub and builds the APK.
