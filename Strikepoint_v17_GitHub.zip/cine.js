import * as THREE from 'three';
// Short in-engine movies: scripted camera shots with letterbox, captions and a procedural helicopter.
export function makeHeli() {
  const g = new THREE.Group(), body = new THREE.MeshStandardMaterial({ color: 0x3b4536, roughness: .55, metalness: .35 }), dark = new THREE.MeshStandardMaterial({ color: 0x15181a, roughness: .5, metalness: .5 }),
    glass = new THREE.MeshStandardMaterial({ color: 0x0a1218, roughness: .08, metalness: .9 });
  const add = (geo, m, p, r, s) => { const o = new THREE.Mesh(geo, m); o.position.set(...p); if (r) o.rotation.set(...r); if (s) o.scale.set(...s); o.castShadow = true; g.add(o); return o; };
  const S = new THREE.SphereGeometry(1, 18, 12), C = new THREE.CylinderGeometry(1, 1, 1, 12), B = new THREE.BoxGeometry(1, 1, 1);
  add(S, body, [0, 0, 0], null, [1.25, 1.1, 2.7]); add(S, glass, [0, .3, 1.7], null, [1.0, .75, 1.3]);
  add(new THREE.CylinderGeometry(.28, .12, 5, 10), body, [0, .25, -4.2], [Math.PI / 2, 0, 0]); add(B, body, [0, 1.0, -6.4], null, [.08, 1.5, .9]); add(B, body, [0, .3, -6.0], null, [1.8, .08, .6]);
  add(C, dark, [0, 1.3, 0], null, [.18, .6, .18]);
  for (const s of [-1, 1]) { add(B, dark, [s * 1.0, -1.3, 0], null, [.1, .1, 3.2]); add(B, dark, [s * .8, -.8, .9], [0, 0, s * .4], [.08, .9, .08]); add(B, dark, [s * .8, -.8, -.9], [0, 0, s * .4], [.08, .9, .08]); add(B, dark, [s * 1.6, -.1, .4], null, [.5, .35, 1.3]); }
  const rotor = new THREE.Group(); rotor.position.y = 1.65; g.add(rotor);
  for (let i = 0; i < 4; i++) { const b = new THREE.Mesh(B, dark); b.scale.set(8.4, .05, .32); b.rotation.y = i * Math.PI / 2; rotor.add(b); }
  const disc = new THREE.Mesh(new THREE.CircleGeometry(4.3, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .07, side: THREE.DoubleSide, depthWrite: false })); disc.rotation.x = -Math.PI / 2; rotor.add(disc);
  const tail = new THREE.Group(); tail.position.set(.3, 1.0, -6.4); g.add(tail); for (let i = 0; i < 2; i++) { const b = new THREE.Mesh(B, dark); b.scale.set(.05, 1.8, .14); b.rotation.x = i * Math.PI / 2; tail.add(b); }
  g.userData = { rotor, tail }; g.visible = false; return g;
}
const ss = x => x * x * (3 - 2 * x);
export class Cine {
  constructor(camera, ui) { this.cam = camera; this.ui = ui; this.active = false; this.shots = []; this.i = 0; this.t = 0; this.onEnd = null; }
  play(shots, onEnd) { this.shots = shots; this.i = 0; this.t = 0; this.active = true; this.onEnd = onEnd; this.ui.on(true); this._enter(); }
  _enter() { const s = this.shots[this.i]; this.ui.caption(s.cap || '', s.big, s.cls); if (s.start) s.start(); }
  skip() { if (!this.active) return; this.active = false; this.ui.on(false); for (const s of this.shots) if (s.end) s.end(); const f = this.onEnd; this.onEnd = null; f && f(); }
  update(dt) {
    if (!this.active) return; const s = this.shots[this.i]; this.t += dt; const k = Math.min(1, this.t / s.dur), e = s.linear ? k : ss(k), c = s.cam(e, k);
    this.cam.position.set(...c.pos); this.cam.lookAt(...c.look); if (c.fov && Math.abs(this.cam.fov - c.fov) > .01) { this.cam.fov = c.fov; this.cam.updateProjectionMatrix(); }
    if (s.tick) s.tick(e, dt);
    if (this.t >= s.dur) { if (s.end) s.end(); this.i++; this.t = 0; if (this.i >= this.shots.length) { this.active = false; this.ui.on(false); const f = this.onEnd; this.onEnd = null; f && f(); } else this._enter(); }
  }
}
export const lerp3 = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
