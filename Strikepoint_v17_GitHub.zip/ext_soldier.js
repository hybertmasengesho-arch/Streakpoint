// Animated glTF soldier (Mixamo "Vanguard") with arm IK onto a procedural rifle. Used when models/Soldier.glb exists.
import * as THREE from 'three';
import { clone } from 'three/addons/utils/SkeletonUtils.js';
import { M } from './models.js';
import { buildRifleGeo } from './character.js';

const TINT = { rifleman: 0xffffff, heavy: 0x7c8086, runner: 0xf0d2a8 };
let rifleGeo = null;
const V = () => new THREE.Vector3(), Q = () => new THREE.Quaternion();
const _S = V(), _E = V(), _H = V(), _T = V(), _d = V(), _n = V(), _p = V(), _bq = Q(), _pq = Q(), _q = Q(), _c = V();

function aim(bone, child, dir) {
  bone.updateWorldMatrix(true, false); child.updateWorldMatrix(true, false);
  bone.getWorldPosition(_S); child.getWorldPosition(_c); _d.copy(_c).sub(_S).normalize(); _q.setFromUnitVectors(_d, dir);
  bone.getWorldQuaternion(_bq); bone.parent.getWorldQuaternion(_pq); bone.quaternion.copy(_pq.invert().multiply(_q.multiply(_bq))); bone.updateMatrixWorld(true);
}

export function makeExt(sol, T, key) {
  if (!M.soldier) return null;
  const holder = new THREE.Group(); sol.root.add(holder);
  const mk = (src, anims, hiRes) => {
    const m = clone(src.scene); m.scale.setScalar(.98); holder.add(m); const mats = [], meshes = [], bones = {};
    m.traverse(o => { if (o.isBone) bones[o.name.replace('mixamorig', '')] = o; if (o.isMesh) { o.frustumCulled = false; o.castShadow = hiRes; o.userData = { enemy: sol, part: 'body', ext: true }; o.material = o.material.clone(); o.material.color.multiply(new THREE.Color(TINT[key] || 0xffffff)); o.material.emissive = new THREE.Color(0xff2200); o.material.emissiveIntensity = 0; mats.push(o.material); meshes.push(o); } });
    const mixer = new THREE.AnimationMixer(m), acts = {}; for (const c of anims) { const n = c.name.toLowerCase(); if (['idle', 'walk', 'run'].includes(n)) { acts[n] = mixer.clipAction(c); acts[n].play(); acts[n].enabled = true; acts[n].setEffectiveWeight(n === 'idle' ? 1 : 0); } }
    return { m, mats, meshes, bones, mixer, acts };
  };
  const hi = mk(M.soldier, M.soldier.animations, true), lo = M.soldierLo ? mk(M.soldierLo, M.soldierLo.animations, false) : null; if (lo) lo.m.visible = false;
  if (!rifleGeo) rifleGeo = buildRifleGeo();
  const rifle = new THREE.Mesh(rifleGeo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .55, metalness: .5 })); rifle.castShadow = true; rifle.scale.setScalar(1);
  const RT = new THREE.Vector3(-.1, 1.2, .3), LT = new THREE.Vector3(.06, 1.22, .72); rifle.position.copy(RT).add(new THREE.Vector3(0, .015, -.04)); holder.add(rifle);
  const E = { holder, hi, lo, rifle, lod: 0, kickV: 0, w: { idle: 1, walk: 0, run: 0 }, shadow: true,
    all() { return lo ? hi.mats.concat(lo.mats) : hi.mats; },
    curMeshes() { return (this.lod && lo) ? lo.meshes : hi.meshes; },
    setLod(l) { if (!lo) return; this.lod = l; hi.m.visible = !l; lo.m.visible = !!l; },
    setShadow(v) { for (const m of hi.meshes) m.castShadow = v; },
    flash(v) { for (const mt of this.all()) mt.emissiveIntensity = v; },
    kick() { this.kickV = 1; },
    die(t) { const e = Math.min(1, t / .6), k = 1 - (1 - e) * (1 - e); holder.rotation.x = -k * 1.5; holder.position.y = -k * .12; for (const s of [hi, lo]) if (s) s.mixer.timeScale = Math.max(0, 1 - k); },
    update(dt, speed) {
      const target = speed < .35 ? 'idle' : speed < 2.4 ? 'walk' : 'run';
      for (const n of ['idle', 'walk', 'run']) { const f = Math.min(1, dt * 7); this.w[n] += ((n === target ? 1 : 0) - this.w[n]) * f; for (const s of [hi, lo]) if (s && s.acts[n]) { s.acts[n].setEffectiveWeight(this.w[n]); if (n === 'walk') s.acts[n].setEffectiveTimeScale(Math.max(.6, speed / 1.5)); if (n === 'run') s.acts[n].setEffectiveTimeScale(Math.max(.8, speed / 3.2)); } }
      const cur = this.lod && lo ? lo : hi; cur.mixer.update(dt);
      this.kickV = Math.max(0, this.kickV - dt * 8); rifle.position.z = RT.z - .04 - this.kickV * .05;
      if (cur === hi) {
        holder.updateMatrixWorld(true);
        for (const side of ['Left', 'Right']) {
          const A = hi.bones[side + 'Arm'], F = hi.bones[side + 'ForeArm'], H = hi.bones[side + 'Hand']; if (!A || !F || !H) continue;
          A.getWorldPosition(_S); F.getWorldPosition(_E); H.getWorldPosition(_H); const l1 = _S.distanceTo(_E), l2 = _E.distanceTo(_H);
          _T.copy(side === 'Right' ? RT : LT.clone().setZ(rifle.position.z + .5).setY(rifle.position.y - .0)); if (side === 'Right') _T.set(rifle.position.x, rifle.position.y - .015, rifle.position.z + .04); else _T.set(rifle.position.x + .005, rifle.position.y - .015, rifle.position.z + .5);
          holder.localToWorld(_T); _d.copy(_T).sub(_S); const D = Math.min(_d.length(), (l1 + l2) * .995), n = _d.clone().normalize(), a = (l1 * l1 - l2 * l2 + D * D) / (2 * D), h = Math.sqrt(Math.max(l1 * l1 - a * a, 0));
          const out = new THREE.Vector3(side === 'Left' ? 1 : -1, 0, 0).transformDirection(holder.matrixWorld), up = new THREE.Vector3(0, 1, 0);
          _p.copy(out).multiplyScalar(.6).addScaledVector(up, -1).addScaledVector(n, -(out.clone().multiplyScalar(.6).addScaledVector(up, -1).dot(n))).normalize();
          _E.copy(_S).addScaledVector(n, a).addScaledVector(_p, h);
          aim(A, F, _n.copy(_E).sub(_S).normalize()); F.getWorldPosition(_E); aim(F, H, _n.copy(_T).sub(_E).normalize());
        }
      }
    },
  };
  return E;
}
