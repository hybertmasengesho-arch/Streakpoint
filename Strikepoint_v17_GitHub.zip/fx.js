import * as THREE from 'three';
// Pooled billboard particles (smoke, fire, sparks, blood, dust) + physical brass casings.
export class Particles {
  constructor(scene) {
    const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 1, 32, 32, 31);
    g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.4, 'rgba(255,255,255,.55)'); g.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(c); this.list = [];
    for (let i = 0; i < 180; i++) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false })); s.visible = false; s.userData = { life: 0 }; scene.add(s); this.list.push(s); }
    this.i = 0;
    this.casings = Array.from({ length: 24 }, () => { const m = new THREE.Mesh(new THREE.CylinderGeometry(.008, .008, .035, 6), new THREE.MeshStandardMaterial({ color: 0xc9a24a, metalness: 1, roughness: .35 })); m.visible = false; m.userData = { life: 0, v: new THREE.Vector3() }; scene.add(m); return m; }); this.ci = 0;
  }
  /** o: {p:Vector3, v:[x,y,z], life, s0, s1, color, add, op, grav, drag} */
  spawn(o) {
    const s = this.list[this.i = (this.i + 1) % this.list.length], d = s.userData;
    s.position.copy(o.p); d.v = o.v || [0, 0, 0]; d.life = d.max = o.life || 1; d.s0 = o.s0 || .3; d.s1 = o.s1 || 1; d.op = o.op ?? 1; d.grav = o.grav || 0; d.drag = o.drag ?? 1.5;
    s.material.color.set(o.color ?? 0xffffff); s.material.blending = o.add ? THREE.AdditiveBlending : THREE.NormalBlending; s.material.rotation = Math.random() * 6; s.visible = true; s.scale.setScalar(d.s0);
  }
  casing(p, v) { const m = this.casings[this.ci = (this.ci + 1) % this.casings.length], d = m.userData; m.position.copy(p); d.v.copy(v); d.life = 2.5; m.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3); m.visible = true; }
  update(dt) {
    for (const s of this.list) { const d = s.userData; if (d.life <= 0) continue; d.life -= dt; if (d.life <= 0) { s.visible = false; continue; } const k = 1 - d.life / d.max;
      s.position.x += d.v[0] * dt; s.position.y += d.v[1] * dt; s.position.z += d.v[2] * dt; d.v[1] -= d.grav * dt; const f = Math.max(0, 1 - d.drag * dt); d.v[0] *= f; d.v[1] *= f; d.v[2] *= f;
      s.scale.setScalar(d.s0 + (d.s1 - d.s0) * Math.sqrt(k)); s.material.opacity = d.op * (1 - k) * (k < .08 ? k / .08 : 1); }
    for (const m of this.casings) { const d = m.userData; if (d.life <= 0) continue; d.life -= dt; if (d.life <= 0) { m.visible = false; continue; }
      if (m.position.y > .02) { d.v.y -= 12 * dt; m.position.addScaledVector(d.v, dt); m.rotation.x += 14 * dt; m.rotation.z += 9 * dt; } else { m.position.y = .02; d.v.set(0, 0, 0); } }
  }
}
