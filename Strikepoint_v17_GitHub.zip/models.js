import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
// Optional high-quality glTF assets (Blender/Mixamo made). Missing files are fine: the game falls back to procedural models.
export const M = {};
export async function loadModels(onProgress) {
  if (new URLSearchParams(location.search).get('models') === '0') return M;
  const L = new GLTFLoader(), dr = new DRACOLoader(); dr.setDecoderPath('lib/addons/libs/draco/gltf/'); L.setDRACOLoader(dr);
  const list = [['soldier', 'models/Soldier.glb'], ['soldierLo', 'models/Soldier_lo.glb'], ['ferrari', 'models/ferrari.glb']]; let i = 0;
  for (const [k, p] of list) { try { M[k] = await L.loadAsync(p); } catch (e) { console.warn('model not loaded', p); } onProgress && onProgress(++i / list.length); }
  return M;
}
