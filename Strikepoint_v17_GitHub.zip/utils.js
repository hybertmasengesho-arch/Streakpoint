import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const wrapPi = a => ((a + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI;
export const rand = (a, b) => a + Math.random() * (b - a);

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler();
const _p = new THREE.Vector3(), _s = new THREE.Vector3();

/** Clone a geometry, bake a transform + a flat vertex colour into it. rot = [x,y,z] euler or Quaternion. */
export function bake(geo, color, pos = [0, 0, 0], rot = [0, 0, 0], scl = [1, 1, 1]) {
  const g = geo.clone();
  const q = rot instanceof THREE.Quaternion ? rot : _q.setFromEuler(_e.set(rot[0], rot[1], rot[2]));
  _m.compose(_p.set(pos[0], pos[1], pos[2]), q, _s.set(scl[0], scl[1], scl[2]));
  g.applyMatrix4(_m);
  const n = g.attributes.position.count, arr = new Float32Array(n * 3);
  if (typeof color === 'function') {
    const P = g.attributes.position, N = g.attributes.normal;
    for (let i = 0; i < n; i++) { const c = color(P.getX(i), P.getY(i), P.getZ(i), N.getX(i), N.getY(i), N.getZ(i)); arr[i * 3] = c[0]; arr[i * 3 + 1] = c[1]; arr[i * 3 + 2] = c[2]; }
  } else { const c = new THREE.Color(color); for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; } }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}
export function mergeColored(list) {
  const out = mergeGeometries(list.map(g => g.index ? g.toNonIndexed() : g), false);
  out.computeBoundingSphere(); out.computeBoundingBox();
  return out;
}
/** Tapered cylinder between two points (a -> b), r0 at a, r1 at b. */
export function seg(a, b, r0, r1, color, radial = 8) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), len = A.distanceTo(B);
  const geo = new THREE.CylinderGeometry(r1, r0, len, radial, 1);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), B.clone().sub(A).normalize());
  return bake(geo, color, A.add(B).multiplyScalar(.5).toArray(), q);
}

// ---------- 2D collision against axis aligned boxes ({minX,maxX,minZ,maxZ,h}) ----------
const OUT = { x: 0, z: 0, hit: false, nx: 0, nz: 0 };
export function resolveCircle(x, z, r, colliders, feetY = 0) {
  let hit = false, nx = 0, nz = 0;
  for (let i = 0; i < colliders.length; i++) {
    const c = colliders[i];
    if (feetY > c.h - 0.15) continue;
    const cx = Math.max(c.minX, Math.min(x, c.maxX)), cz = Math.max(c.minZ, Math.min(z, c.maxZ));
    const dx = x - cx, dz = z - cz, d2 = dx * dx + dz * dz;
    if (d2 < r * r) {
      if (d2 > 1e-8) { const d = Math.sqrt(d2), push = r - d; x += dx / d * push; z += dz / d * push; nx += dx / d; nz += dz / d; }
      else {
        const l = x - c.minX, rr = c.maxX - x, t = z - c.minZ, b = c.maxZ - z, m = Math.min(l, rr, t, b);
        if (m === l) { x = c.minX - r; nx -= 1; } else if (m === rr) { x = c.maxX + r; nx += 1; }
        else if (m === t) { z = c.minZ - r; nz -= 1; } else { z = c.maxZ + r; nz += 1; }
      }
      hit = true;
    }
  }
  OUT.x = x; OUT.z = z; OUT.hit = hit;
  const l = Math.hypot(nx, nz) || 1; OUT.nx = nx / l; OUT.nz = nz / l;
  return OUT;
}
/** Ray vs box slab test. Returns distance or Infinity. */
export function rayBox(ox, oy, oz, dx, dy, dz, c) {
  let t0 = 0, t1 = Infinity;
  const mins = [c.minX, c.minY ?? 0, c.minZ], maxs = [c.maxX, c.h, c.maxZ], o = [ox, oy, oz], d = [dx, dy, dz];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) { if (o[i] < mins[i] || o[i] > maxs[i]) return Infinity; continue; }
    let a = (mins[i] - o[i]) / d[i], b = (maxs[i] - o[i]) / d[i];
    if (a > b) { const t = a; a = b; b = t; }
    t0 = Math.max(t0, a); t1 = Math.min(t1, b);
    if (t0 > t1) return Infinity;
  }
  return t0;
}
export function firstWallHitInfo(ox, oy, oz, dx, dy, dz, colliders, maxT = 200) {
  let best = maxT, hit = null; for (let i = 0; i < colliders.length; i++) { const t = rayBox(ox, oy, oz, dx, dy, dz, colliders[i]); if (t < best) { best = t; hit = colliders[i]; } } return { t: best, c: hit };
}
export function raySphere(ox, oy, oz, dx, dy, dz, cx, cy, cz, r) {
  const lx = cx - ox, ly = cy - oy, lz = cz - oz, tca = lx * dx + ly * dy + lz * dz;
  if (tca < 0) return Infinity;
  const d2 = lx * lx + ly * ly + lz * lz - tca * tca;
  if (d2 > r * r) return Infinity;
  return tca - Math.sqrt(r * r - d2);
}
export function firstWallHit(ox, oy, oz, dx, dy, dz, colliders, maxT = 200) {
  let best = maxT;
  for (let i = 0; i < colliders.length; i++) { const t = rayBox(ox, oy, oz, dx, dy, dz, colliders[i]); if (t < best) best = t; }
  return best;
}

// ---------- organic shape helpers ----------
/** Box with rounded edges + analytic smooth normals. */
export function roundBox(w, h, d, r, seg = 3) {
  const g = new THREE.BoxGeometry(w, h, d, seg, seg, seg), p = g.attributes.position, nr = g.attributes.normal;
  const hx = w / 2 - r, hy = h / 2 - r, hz = d / 2 - r, v = new THREE.Vector3(), inner = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i); inner.set(clamp(v.x, -hx, hx), clamp(v.y, -hy, hy), clamp(v.z, -hz, hz));
    v.sub(inner); const l = v.length(); if (l > 1e-6) { v.multiplyScalar(1 / l); nr.setXYZ(i, v.x, v.y, v.z); v.multiplyScalar(r); } else v.set(0, 0, 0);
    p.setXYZ(i, inner.x + v.x, inner.y + v.y, inner.z + v.z);
  }
  return g;
}
/** Tapered capsule with hemispherical ends; centre of end spheres at (0,0,0) and (0,len,0). */
export function capsuleGeo(len, r0, r1, radial = 12, capSeg = 4, midSeg = 3) {
  const pts = [];
  for (let i = 0; i <= capSeg; i++) { const a = -Math.PI / 2 + (i / capSeg) * Math.PI / 2; pts.push(new THREE.Vector2(Math.max(r0 * Math.cos(a), 1e-4), r0 * Math.sin(a))); }
  for (let i = 1; i < midSeg; i++) { const t = i / midSeg; pts.push(new THREE.Vector2(r0 + (r1 - r0) * t, len * t)); }
  for (let i = 0; i <= capSeg; i++) { const a = (i / capSeg) * Math.PI / 2; pts.push(new THREE.Vector2(Math.max(r1 * Math.cos(a), 1e-4), len + r1 * Math.sin(a))); }
  return new THREE.LatheGeometry(pts, radial);
}
/** Capsule between two points. */
export function limb(a, b, r0, r1, color, radial = 12) {
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), len = A.distanceTo(B);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), B.clone().sub(A).normalize());
  return bake(capsuleGeo(len, r0, r1, radial), color, a, q);
}
/** Lathe from [r,y] pairs, optional xz scale. */
export function latheGeo(pairs, seg = 16) { return new THREE.LatheGeometry(pairs.map(p => new THREE.Vector2(Math.max(p[0], 1e-4), p[1])), seg); }
/** Cheap smooth noise in [0,1]. */
export function noise3(x, y, z) { return .5 + .25 * Math.sin(x * 21.3 + y * 7.1 + 1.3) * Math.cos(z * 19.7 - y * 5.3) + .25 * Math.sin((x + z) * 33.1 + y * 13.7) * Math.cos(x * 9.1 - z * 12.9); }
export { THREE };
