// Strikepoint 3D — game server.
// Serves the game files AND relays co-op multiplayer messages (rooms of up to 5 players).
// Run:  npm install && npm start      (PORT env var supported; default 3000)
'use strict';
const http = require('http'), fs = require('fs'), path = require('path');
const { WebSocketServer } = require('ws');

const os = require('os');
const lanIPs = () => Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
const PORT = process.env.PORT || 3000, MAX_PLAYERS = 5, ROOT = __dirname;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.wasm': 'application/wasm', '.glb': 'model/gltf-binary', '.fbx': 'application/octet-stream', '.md': 'text/plain; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };
const HIDDEN = /^\/(server\.js|package(-lock)?\.json|node_modules)(\/|$)/;

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Private-Network', 'true');
  if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Headers': '*' }); return res.end(); }
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/lan-ping') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ game: 'strikepoint', v: 13, port: +PORT, ips: lanIPs(), rooms: [...rooms.values()].filter(r => r.lan).map(r => ({ code: r.code, players: r.players.size })) })); }
  if (p === '/lan') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(lanIPs().map(ip => `${ip}:${PORT}`))); }
  if (p === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT) || HIDDEN.test(p)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
});

// ---------------- rooms ----------------
const rooms = new Map();                                   // code -> { code, players: Map(id -> {id,name,ws}), host, started }
const LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const newCode = () => { for (let n = 0; n < 200; n++) { let c = ''; for (let i = 0; i < 4; i++) c += LETTERS[Math.floor(Math.random() * LETTERS.length)]; if (!rooms.has(c)) return c; } return null; };
const send = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
const cleanName = s => String(s || 'Operator').replace(/[^\w \-.]/g, '').trim().slice(0, 12) || 'Operator';
const roster = r => ({ t: 'roster', room: r.code, host: r.host, started: r.started, players: [...r.players.values()].map(p => ({ id: p.id, name: p.name })) });
const broadcast = (r, o) => { for (const p of r.players.values()) send(p.ws, o); };

function addPlayer(r, ws, name) {
  let id = 1; while (r.players.has(id)) id++;                // smallest free slot 1..5
  const p = { id, name: cleanName(name), ws }; r.players.set(id, p); ws.pid = id; ws.room = r;
  if (!r.host) r.host = id;
  send(ws, { t: 'joined', id, room: r.code, host: r.host, started: r.started, n: r.n });
  broadcast(r, roster(r));
}
function removePlayer(ws) {
  const r = ws.room; if (!r) return; r.players.delete(ws.pid); ws.room = null;
  if (!r.players.size) { rooms.delete(r.code); return; }
  if (r.host === ws.pid) r.host = Math.min(...r.players.keys());   // host migration: lowest slot takes over
  broadcast(r, { t: 'left', id: ws.pid }); broadcast(r, roster(r));
}

const wss = new WebSocketServer({ server, path: '/mp', maxPayload: 16 * 1024 });
wss.on('connection', ws => {
  ws.alive = true; ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'create' && !ws.room) {
      const code = newCode(); if (!code) return send(ws, { t: 'err', msg: 'Server is full, try later' });
      const r = { code, players: new Map(), host: 0, started: false, n: 35 }; rooms.set(code, r); addPlayer(r, ws, m.name);
    } else if (m.t === 'lan' && !ws.room) {                      // Blur-style LAN: join the open LAN room, or create one automatically
      let r = [...rooms.values()].find(x => x.lan && x.players.size < MAX_PLAYERS);
      if (!r) { const code = newCode(); if (!code) return send(ws, { t: 'err', msg: 'Server is full, try later' }); r = { code, players: new Map(), host: 0, started: false, n: 35, lan: true }; rooms.set(code, r); }
      addPlayer(r, ws, m.name);
    } else if (m.t === 'join' && !ws.room) {
      const r = rooms.get(String(m.room || '').toUpperCase().trim());
      if (!r) return send(ws, { t: 'err', msg: 'Room not found' });
      if (r.players.size >= MAX_PLAYERS) return send(ws, { t: 'err', msg: 'Room is full (5/5)' });
      addPlayer(r, ws, m.name);
    } else if (m.t === 'start' && ws.room && ws.room.host === ws.pid) {
      ws.room.started = true; ws.room.n = Math.min(35, Math.max(7, ws.room.players.size * 7)); broadcast(ws.room, { t: 'start', n: ws.room.n });
    } else if (m.t === 'msg' && ws.room) {                       // generic relay: to = 'all' | 'host' | <player id>
      const r = ws.room, out = JSON.stringify({ t: 'msg', from: ws.pid, d: m.d });
      if (m.to === 'all') { for (const p of r.players.values()) if (p.ws !== ws && p.ws.readyState === 1) p.ws.send(out); }
      else { const id = m.to === 'host' ? r.host : +m.to, p = r.players.get(id); if (p && p.ws !== ws && p.ws.readyState === 1) p.ws.send(out); }
    } else if (m.t === 'leave') removePlayer(ws);
  });
  ws.on('close', () => removePlayer(ws));
  ws.on('error', () => { });
});
setInterval(() => { for (const ws of wss.clients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; try { ws.ping(); } catch { } } }, 20000);

server.listen(PORT, () => {
  console.log('\n=== STRIKEPOINT LAN SERVER (' + MAX_PLAYERS + ' players per room) ===');
  console.log('On this PC open:  http://localhost:' + PORT);
  for (const ip of lanIPs()) console.log('Phones / other PCs on the same Wi-Fi open:  http://' + ip + ':' + PORT + '   (Android app: type ' + ip + ':' + PORT + ' in the Server box)');
  console.log('=========================================\n');
  if (process.stdout.isTTY && !process.env.NO_BROWSER && !process.env.RENDER) {   // PC: open the game and auto-create the LAN room
    const url = 'http://localhost:' + PORT + '/?lan=1', cmd = process.platform === 'win32' ? `start "" "${url}"` : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
    require('child_process').exec(cmd, () => { });
  }
});
