// Strikepoint — squad roles: RIFLE / SNIPER (overwatch tower) / COMMANDER (dots, tactics, track orders).
// Plugs into game.js through window.__mp and window.__roles (see hooks in game.js).
import * as THREE from 'three';
while (!window.__mp) await new Promise(r => setTimeout(r, 50));
const M = window.__mp, net = M.net, remotes = M.remotes, enemies = M.enemies;
const TOP = 26, ROLES = ['rifle', 'sniper', 'cmdr'], LABEL = { rifle: 'RIFLEMAN', sniper: 'SNIPER', cmdr: 'COMMANDER' };
const TACS = [['HOLD', 'Hold position'], ['ADVANCE', 'Advance to waypoint'], ['FLANK', 'Flank via waypoint'], ['COVER', 'Cover fire — sniper tracks'], ['REGROUP', 'Regroup on commander']];
const S = { role: 'rifle', roles: {}, perched: false, track: 0, sel: 0, zoom: 0, wp: null, order: null, verify: {}, hostiles: [], mapOn: false, t: 0, vt: 0 };
const ZOOMS = [24, 12, 6];

// ---------- sniper tower (visual landmark, placed on a free spot) ----------
const tower = new THREE.Group(); let tx = -56, tz = -56;
for (const [x, z] of [[-56, -56], [56, -56], [-56, 56], [56, 56], [0, -62]]) { try { if (M.world.isFreeSpot(x, z, 4)) { tx = x; tz = z; break; } } catch (e) { } }
const mat = c => new THREE.MeshStandardMaterial({ color: c, roughness: .8, metalness: .2 });
for (const a of [-1, 1]) for (const b of [-1, 1]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(.5, TOP, .5), mat(0x4a4f4d)); leg.position.set(a * 1.8, TOP / 2, b * 1.8); leg.castShadow = true; tower.add(leg); }
for (let h = 4; h < TOP; h += 5) { const br = new THREE.Mesh(new THREE.BoxGeometry(4, .2, 4), mat(0x3a3f3d)); br.position.y = h; tower.add(br); }
const deck = new THREE.Mesh(new THREE.BoxGeometry(5, .35, 5), mat(0x555a57)); deck.position.y = TOP; tower.add(deck);
const rail = new THREE.Mesh(new THREE.BoxGeometry(5, .4, .15), mat(0x2f3432)), deckParts = [deck]; for (const [x, z, r] of [[0, 2.4, 0], [0, -2.4, 0], [2.4, 0, 1.57], [-2.4, 0, 1.57]]) { const m = rail.clone(); m.position.set(x, TOP + .5, z); m.rotation.y = r; tower.add(m); deckParts.push(m); }
tower.position.set(tx, 0, tz); M.scene.add(tower);

// ---------- waypoint beacon ----------
const beacon = new THREE.Mesh(new THREE.CylinderGeometry(.5, .5, 40, 12, 1, true), new THREE.MeshBasicMaterial({ color: 0xffc83a, transparent: true, opacity: .35, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
beacon.visible = false; beacon.position.y = 20; M.scene.add(beacon);

// ---------- UI ----------
const css = document.createElement('style'); css.textContent = `
#rl-ui{position:fixed;inset:0;pointer-events:none;z-index:40;font-family:system-ui,sans-serif;color:#fff}
#rl-ui .b{pointer-events:auto;background:rgba(10,14,20,.78);border:1.5px solid #4ad0ff;color:#fff;border-radius:7px;padding:5px 8px;font:700 11px system-ui;touch-action:manipulation;white-space:nowrap}
#rl-ui .b.on{background:#4ad0ff;color:#06141c}#rl-ui .b.warn{border-color:#ffc83a}
#rl-chip{position:static}
#rl-side{position:absolute;right:64px;top:46px;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:5px;max-width:46vw;z-index:2}
#rl-banner{position:absolute;left:50%;top:124px;transform:translateX(-50%);background:rgba(10,14,20,.8);border-left:4px solid #ffc83a;padding:6px 14px;font:700 13px system-ui;display:none;white-space:nowrap}
#rl-info{position:absolute;left:50%;transform:translateX(-50%);top:100px;text-align:center;font:700 12px system-ui;text-shadow:0 1px 3px #000;max-width:50vw}
.rl-dot{position:absolute;width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:50%;border:3px solid #4ad0ff;background:rgba(74,208,255,.25);pointer-events:auto;display:none}
.rl-dot.sel{border-color:#ffc83a;background:rgba(255,200,58,.35)}.rl-dot.trk{box-shadow:0 0 0 3px #ff4a4a}
.rl-dot i{position:absolute;left:50%;top:-16px;transform:translateX(-50%);font:700 10px system-ui;font-style:normal;white-space:nowrap;text-shadow:0 1px 2px #000}
#rl-map{position:absolute;left:34%;top:52%;width:min(76vh,46vw);height:min(76vh,46vw);z-index:1;transform:translate(-50%,-50%);background:rgba(8,14,20,.92);border:2px solid #4ad0ff;border-radius:6px;pointer-events:auto;display:none}
#rl-scope{position:absolute;inset:0;display:none;background:radial-gradient(circle at 50% 50%,transparent 24%,rgba(0,0,0,.92) 25.5%)}
#rl-scope:before{content:"";position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(0,0,0,.7)}#rl-scope:after{content:"";position:absolute;top:50%;left:0;right:0;height:1px;background:rgba(0,0,0,.7)}`;
document.head.appendChild(css);
const ui = document.createElement('div'); ui.id = 'rl-ui'; ui.style.display = 'none';
ui.innerHTML = `<div id="rl-scope"></div><button id="rl-chip" class="b"></button><div id="rl-side"></div><div id="rl-banner"></div><div id="rl-info"></div><canvas id="rl-map" width="480" height="480"></canvas>`;
document.body.appendChild(ui);
const $ = id => ui.querySelector('#' + id), chip = $('rl-chip'), side = $('rl-side'), banner = $('rl-banner'), info = $('rl-info'), map = $('rl-map'), mx = map.getContext('2d'), scope = $('rl-scope');
const mk = (txt, fn, cls = '') => { const b = document.createElement('button'); b.className = 'b ' + cls; b.textContent = txt; b.addEventListener('click', e => { e.stopPropagation(); fn(); }); return b; };
const nameOf = id => id === net.id ? 'YOU' : (remotes.get(id) || {}).name || ('P' + id);
const toast = (t, ms = 3500) => { banner.textContent = t; banner.style.display = 'block'; clearTimeout(toast.h); toast.h = setTimeout(() => banner.style.display = 'none', ms); };
const holder = r => Object.keys(S.roles).map(Number).find(id => id !== net.id && S.roles[id] === r);

function setRole(r) {
  if ((r === 'sniper' || r === 'cmdr') && holder(r)) { toast(`${LABEL[r]} is already ${nameOf(holder(r))}`); return; }
  if (S.role === 'sniper' && r !== 'sniper') perch(false);
  S.role = r; S.roles[net.id] = r; net.all({ k: 'rl', r }); buildSide();
}
function perch(on) {
  if (on && S.role !== 'sniper') return; S.perched = on; net.all({ k: 'pc', on });
  if (on) { S.zoom = 0; M.player.x = tx; M.player.z = tz + 2.2; } buildSide();
}
function sendTrack(id) { S.track = id; net.all({ k: 'tk', id }); buildSide(); }
function order(t) {
  const tgt = S.sel || 0, d = { k: 'tc', t, wp: S.wp, to: tgt };
  net.all(d); applyOrder(net.id, d);
  if (t === 'COVER') { if (!tgt) { toast('Select a teammate dot first'); return; } const sn = holder('sniper'); if (sn) { net.to(sn, { k: 'tk', id: tgt }); toast(`COVER FIRE: sniper ${nameOf(sn)} tracks ${nameOf(tgt)}`); } else toast('No sniper in squad'); }
}
const SAY = { HOLD: 'Hold position', ADVANCE: 'Advance', FLANK: 'Flank', COVER: 'Cover fire', REGROUP: 'Regroup' };
function speak(t) { try { if (!window.speechSynthesis) return; const u = new SpeechSynthesisUtterance(t); u.rate = 1.05; u.volume = .8; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { } }
function applyOrder(from, d) {
  if (from !== net.id && (!d.to || d.to === net.id) && SAY[d.t]) speak('Commander: ' + SAY[d.t]);
  S.order = { t: d.t, wp: d.wp, to: d.to, from, at: performance.now() };
  if (d.wp) { beacon.position.x = d.wp[0]; beacon.position.z = d.wp[1]; beacon.visible = true; }
  if (!d.to || d.to === net.id || from === net.id) toast(`ORDER ${d.t}${d.to ? ' → ' + nameOf(d.to) : ' → ALL'}`, 5000);
}
function buildSide() {
  chip.textContent = 'ROLE [O]: ' + LABEL[S.role]; chip.className = 'b ' + (S.role !== 'rifle' ? 'on' : ''); side.replaceChildren(chip);
  if (S.role === 'sniper') {
    side.append(mk(S.perched ? 'DESCEND' : 'CLIMB TO PERCH', () => perch(!S.perched), S.perched ? 'on' : ''));
    if (S.perched) { side.append(mk('SCOPE ' + ZOOMS[S.zoom] + '°', () => { S.zoom = (S.zoom + 1) % 3; buildSide(); })); if (S.track) side.append(mk('RELEASE TRACK', () => sendTrack(0), 'warn')); }
  } else if (S.role === 'cmdr') {
    side.append(mk(S.mapOn ? 'CLOSE MAP [M]' : 'TACTICAL MAP [M]', () => { S.mapOn = !S.mapOn; if (S.mapOn) document.exitPointerLock?.(); buildSide(); }, S.mapOn ? 'on' : ''));
    if (S.sel) side.append(mk(S.track === S.sel ? 'STOP SNIPER TRACK' : 'SNIPER TRACK ' + nameOf(S.sel), () => { const sn = holder('sniper'); if (!sn) return toast('No sniper in squad'); net.to(sn, { k: 'tk', id: S.track === S.sel ? 0 : S.sel }); S.track = S.track === S.sel ? 0 : S.sel; buildSide(); }, 'warn'));
    for (const [t, tip] of TACS) side.append(mk(t, () => order(t)));
    if (S.wp) side.append(mk('CLEAR WAYPOINT', () => { S.wp = null; beacon.visible = false; net.all({ k: 'tc', t: 'HOLD', wp: null, to: 0 }); }, 'warn'));
  }
}
chip.addEventListener('click', e => { e.stopPropagation(); let i = ROLES.indexOf(S.role); for (let k = 0; k < 3; k++) { i = (i + 1) % 3; const r = ROLES[i]; if (r === 'rifle' || !holder(r)) { setRole(r); return; } } });   // skips roles another player already holds

// ---------- commander dots (over each teammate) ----------
const dots = new Map();
function dotFor(id) { let d = dots.get(id); if (d) return d; d = document.createElement('div'); d.className = 'rl-dot'; d.innerHTML = '<i></i>'; d.addEventListener('click', e => { e.stopPropagation(); S.sel = S.sel === id ? 0 : id; buildSide(); }); ui.appendChild(d); dots.set(id, d); return d; }
const v3 = new THREE.Vector3();
function updateDots() {
  for (const [id, d] of dots) if (!remotes.has(id) || S.role !== 'cmdr') d.style.display = 'none';
  if (S.role !== 'cmdr') return;
  for (const r of remotes.values()) {
    const d = dotFor(r.id); if (!r.got || !r.al) { d.style.display = 'none'; continue; }
    v3.set(r.x, (r.ey || 1.7) + .9, r.z).project(M.camera);
    if (v3.z > 1 || Math.abs(v3.x) > 1.05 || Math.abs(v3.y) > 1.05) { d.style.display = 'none'; continue; }
    d.style.display = 'block'; d.style.left = ((v3.x + 1) / 2 * innerWidth) + 'px'; d.style.top = ((1 - v3.y) / 2 * innerHeight) + 'px';
    d.className = 'rl-dot' + (S.sel === r.id ? ' sel' : '') + (S.track === r.id ? ' trk' : '');
    const vf = S.verify[r.id]; d.firstChild.textContent = r.name + (S.roles[r.id] && S.roles[r.id] !== 'rifle' ? ' [' + S.roles[r.id].toUpperCase() + ']' : '') + (vf ? (vf.n ? ` ⚠${vf.n}` : ' ✔') : '');
    d.firstChild.style.color = vf && vf.n ? '#ff6a5a' : '#fff';
  }
}
// ---------- tactical map (commander): tap a dot to select, tap ground to set waypoint ----------
const HALF = M.world.half || 110, mpx = (x, z) => [(x + HALF) / (2 * HALF) * 480, (z + HALF) / (2 * HALF) * 480];
function drawMap() {
  map.style.display = S.mapOn && S.role === 'cmdr' ? 'block' : 'none'; if (map.style.display === 'none') return;
  mx.clearRect(0, 0, 480, 480); mx.fillStyle = '#0a141c'; mx.fillRect(0, 0, 480, 480); mx.strokeStyle = '#1d3340'; for (let i = 1; i < 8; i++) { mx.beginPath(); mx.moveTo(i * 60, 0); mx.lineTo(i * 60, 480); mx.moveTo(0, i * 60); mx.lineTo(480, i * 60); mx.stroke(); }
  mx.fillStyle = '#6b7b86'; let [a, b] = mpx(tx, tz); mx.fillRect(a - 6, b - 6, 12, 12); mx.font = '11px system-ui'; mx.fillText('SNIPER NEST', a - 30, b + 20);
  mx.fillStyle = '#ff5a4a'; for (const h of S.hostiles) { const [p, q] = mpx(h[0], h[1]); mx.beginPath(); mx.arc(p, q, 5, 0, 7); mx.fill(); }
  for (const r of remotes.values()) { if (!r.got) continue; const [p, q] = mpx(r.x, r.z); mx.fillStyle = S.sel === r.id ? '#ffc83a' : '#4ad0ff'; mx.beginPath(); mx.arc(p, q, 8, 0, 7); mx.fill(); mx.fillStyle = '#fff'; mx.fillText(r.name, p + 10, q + 4); }
  { const [p, q] = mpx(M.player.x, M.player.z); mx.fillStyle = '#7dff8a'; mx.fillRect(p - 5, q - 5, 10, 10); }
  if (S.wp) { const [p, q] = mpx(S.wp[0], S.wp[1]); mx.strokeStyle = '#ffc83a'; mx.lineWidth = 3; mx.beginPath(); mx.arc(p, q, 11, 0, 7); mx.stroke(); mx.lineWidth = 1; }
}
map.addEventListener('mousedown', () => document.exitPointerLock?.());
map.addEventListener('click', e => {
  const rc = map.getBoundingClientRect(), px = (e.clientX - rc.left) / rc.width * 480, py = (e.clientY - rc.top) / rc.height * 480; let best = 0, bd = 22;
  for (const r of remotes.values()) { const [p, q] = mpx(r.x, r.z), d = Math.hypot(p - px, q - py); if (d < bd) { bd = d; best = r.id; } }
  if (best) S.sel = S.sel === best ? 0 : best; else { S.wp = [+((px / 480) * 2 * HALF - HALF).toFixed(1), +((py / 480) * 2 * HALF - HALF).toFixed(1)]; beacon.position.x = S.wp[0]; beacon.position.z = S.wp[1]; beacon.visible = true; toast('Waypoint set — pick a tactic'); }
  buildSide();
});

// ---------- sniper: perch camera, auto-track, verify ----------
function aimAt(x, y, z, dt) {
  const dx = x - M.camera.position.x, dy = y - M.camera.position.y, dz = z - M.camera.position.z, L = Math.hypot(dx, dy, dz);
  const ty = Math.atan2(-dx, -dz), tp = Math.asin(dy / L), k = Math.min(1, 6 * dt); let dy_ = ty - M.yaw; dy_ = Math.atan2(Math.sin(dy_), Math.cos(dy_));
  M.look(M.yaw + dy_ * k, M.pitch + (tp - M.pitch) * k);
}
function trackedPoint() { const r = remotes.get(S.track); return r && r.got && r.al ? [r.x, (r.ey || 1.7) - .3, r.z] : null; }
function verifyTick() {
  const p = trackedPoint(); if (!p) return; const near = [];
  for (const e of enemies) if (e.alive && Math.hypot(e.root.position.x - p[0], e.root.position.z - p[2]) < 30) near.push([+e.root.position.x.toFixed(0), +e.root.position.z.toFixed(0)]);
  S.hostiles = near; net.all({ k: 'vf', id: S.track, n: near.length, h: near.slice(0, 6) });
}

// called at the end of game.js updateCamera()
let hid = false;
function cam(camera, dt) {
  if (!S.perched) { scope.style.display = 'none'; if (hid) { hid = false; M.vm.visible = M.fp && !M.driving; for (const p of deckParts) p.visible = true; } return; }
  for (const p of deckParts) p.visible = false;   // so the deck never blocks the sniper's own view
  M.vm.visible = false; hid = true;   // hide the first-person rifle (it would fill the screen when zoomed)
  camera.position.set(tx, TOP + 2, tz);
  if (S.track) { const p = trackedPoint(); if (p) aimAt(p[0], p[1], p[2], dt); }
  camera.rotation.set(M.pitch, M.yaw, 0, 'YXZ'); camera.fov += (ZOOMS[S.zoom] - camera.fov) * Math.min(1, 8 * dt); camera.updateProjectionMatrix();
  scope.style.display = S.zoom > 0 ? 'block' : 'none';
}

function onMsg(from, d) {
  switch (d.k) {
    case 'rl': S.roles[from] = d.r; return true;
    case 'pc': { const r = remotes.get(from); if (r) r.perch = !!d.on; return true; }
    case 'tk': if (S.role === 'sniper') { S.track = d.id; if (d.id) { if (!S.perched) perch(true); toast('TRACKING ' + nameOf(d.id) + ' — commander order'); } buildSide(); } return true;
    case 'vf': S.verify[d.id] = { n: d.n, at: performance.now() }; if (S.role === 'cmdr') S.hostiles = d.h || []; return true;
    case 'tc': applyOrder(from, d); return true;
  }
  return false;
}

function frame(dt) {
  const on = M.MP && M.started; ui.style.display = on ? 'block' : 'none'; if (!on) { S.perched = false; return; }
  if (!chip.textContent) buildSide();
  S.t += dt; if (S.t > 3) { S.t = 0; net.all({ k: 'rl', r: S.role }); if (S.perched) net.all({ k: 'pc', on: true }); }
  for (const id of Object.keys(S.roles)) if (+id !== net.id && !remotes.has(+id)) delete S.roles[id];
  if (S.perched && S.track) { S.vt += dt; if (S.vt > 1) { S.vt = 0; verifyTick(); } }
  // teammates on the tower get lifted so everyone sees the sniper up high
  for (const r of remotes.values()) if (r.sol) r.sol.root.position.y = r.perch ? TOP + .2 : 0;
  if (S.order && S.order.wp) { const o = S.order, el = Math.hypot(M.player.x - o.wp[0], M.player.z - o.wp[1]); info.textContent = `${o.t}${o.to ? ' · ' + nameOf(o.to) : ''} · waypoint ${el.toFixed(0)} m`; } else info.textContent = S.order ? S.order.t : '';
  if (S.perched) info.textContent = (S.track ? `TRACKING ${nameOf(S.track)} · ` : 'FREE LOOK · ') + 'hostiles near target: ' + S.hostiles.length;
  beacon.material.opacity = .25 + .1 * Math.sin(performance.now() / 250);
  updateDots(); drawMap();
}
// ---------- keyboard shortcuts (PC): O role, P perch, M map, N next teammate, T sniper track, 1-5 tactics ----------
addEventListener('keydown', e => {
  if (!ui.style.display || ui.style.display === 'none' || /INPUT|TEXTAREA/.test((e.target || {}).tagName)) return;
  const k = e.code;
  if (k === 'KeyO') chip.click();
  else if (k === 'KeyP') perch(!S.perched);
  else if (k === 'KeyM' && S.role === 'cmdr') { S.mapOn = !S.mapOn; if (S.mapOn) document.exitPointerLock?.(); buildSide(); }
  else if (k === 'KeyN' && S.role === 'cmdr') { const ids = [...remotes.values()].filter(r => r.got).map(r => r.id); if (ids.length) { S.sel = ids[(ids.indexOf(S.sel) + 1) % ids.length]; buildSide(); toast('Selected ' + nameOf(S.sel), 1500); } }
  else if (k === 'KeyT' && S.role === 'cmdr' && S.sel) { const sn = holder('sniper'); if (!sn) return toast('No sniper in squad'); S.track = S.track === S.sel ? 0 : S.sel; net.to(sn, { k: 'tk', id: S.track }); buildSide(); }
  else if (S.role === 'cmdr' && /^Digit[1-5]$/.test(k)) order(TACS[+k.slice(5) - 1][0]);
});
window.__roles = { cam, frame, onMsg, get frozen() { return S.perched; }, state: S };
