// High-detail, organic soldier geometry (rounded plates, capsule limbs, lathe torso, camo vertex-paint).
// Everything is baked into few merged meshes with vertex colours -> cheap to draw, 10+ on screen is fine.
import * as THREE from 'three';
import { bake, mergeColored, roundBox, capsuleGeo, limb as limbRaw, latheGeo, noise3 } from './utils.js';

const col = h => new THREE.Color(h);
const SPHH = new THREE.SphereGeometry(1, 14, 10), SPHL = new THREE.SphereGeometry(1, 8, 6);
const HALFH = new THREE.SphereGeometry(1, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), HALFL = new THREE.SphereGeometry(1, 9, 4, 0, Math.PI * 2, 0, Math.PI / 2);
const ao = ny => .74 + .26 * (ny * .5 + .5);
function solid(hex, low = 0) { const c = col(hex); return (x, y, z, nx, ny) => { const k = ao(ny) * (low ? (y < low ? .72 + .28 * Math.max(0, 1 + (y - low) * 3) : 1) : 1); return [c.r * k, c.g * k, c.b * k]; }; }
function camo(a, b, c, sc = 1) { const A = col(a), B = col(b), C = col(c); return (x, y, z, nx, ny) => { const n = noise3(x * 2.2 * sc, y * 2.2 * sc, z * 2.2 * sc), k = ao(ny), t = n < .42 ? A : n < .62 ? B : C; return [t.r * k, t.g * k, t.b * k]; }; }

export function buildSoldierGeos(key, T, lod = 0) {
  const U = [], H = [], hi = lod === 0, SPH = hi ? SPHH : SPHL, HALF = hi ? HALFH : HALFL, limb = (a, b, r0, r1, c, rad = 12) => limbRaw(a, b, r0, r1, c, hi ? Math.min(rad, 10) : Math.max(5, rad >> 1));
  const ell = (L, c, p, s, r) => L.push(bake(SPH, c, p, r || [0, 0, 0], s));
  const rb = (L, c, p, w, h, d, r, rot) => L.push(bake(roundBox(w, h, d, r, hi ? 2 : 1), c, p, rot || [0, 0, 0]));
  const cyl = (L, c, p, rt, rbm, h, rot, seg = 14) => L.push(bake(new THREE.CylinderGeometry(rt, rbm, h, hi ? Math.min(seg, 12) : 6), c, p, rot || [0, 0, 0]));
  const shirt = camo(T.cloth, T.cloth2, T.cloth3 || T.cloth), pants = camo(T.cloth2, T.cloth, T.cloth3 || T.cloth2, 1.2);
  const vest = solid(T.vest), plate = solid(T.plate), skin = solid(T.head), glove = solid(T.glove), dark = solid(0x16191b), metal = solid(0x26292c);
  const heavy = key === 'heavy', runner = key === 'runner';

  // ---------------- pelvis / belt ----------------
  ell(U, pants, [0, -.04, 0], [.185, .13, .125]);
  U.push(bake(new THREE.TorusGeometry(.17, .022, hi ? 6 : 3, hi ? 18 : 9), vest, [0, .075, 0], [Math.PI / 2, 0, 0], [1.02, .7, 1]));
  rb(U, vest, [.2, .03, .03], .07, .12, .1, .02); rb(U, vest, [-.2, .03, .03], .07, .12, .1, .02); rb(U, vest, [-.185, -.1, .035], .06, .2, .1, .02);   // pouches / holster
  rb(U, metal, [0, .02, .165], .05, .05, .03, .01);                                                                                               // buckle
  // ---------------- torso ----------------
  const torso = [[.15, -.1], [.17, -.02], [.158, .08], [.178, .2], [.205, .34], [.215, .45], [.195, .55], [.13, .62], [.06, .655]];
  U.push(bake(latheGeo(torso, hi ? 16 : 9), shirt, [0, 0, 0], [0, 0, 0], [1, 1, .66]));
  // plate carrier: rounded plates, cummerbund, shoulder straps, pouches
  rb(U, plate, [0, .42, .138], .3, .34, .055, .022, [-.04, 0, 0]); rb(U, plate, [0, .42, -.135], .3, .34, .055, .022, [.04, 0, 0]);
  rb(U, vest, [.205, .3, 0], .07, .22, .21, .025); rb(U, vest, [-.205, .3, 0], .07, .22, .21, .025);
  for (const s of [-1, 1]) { rb(U, vest, [s * .13, .6, .02], .075, .035, .24, .015, [0, 0, s * .12]); }
  for (const x of [-.095, 0, .095]) { rb(U, vest, [x, .235, .185], .08, .12, .05, .015); rb(U, metal, [x, .27, .212], .06, .01, .008, .003); }
  rb(U, vest, [.15, .5, .17], .06, .1, .045, .012); rb(U, vest, [-.15, .5, .17], .06, .1, .045, .012);         // radio + admin
  rb(U, dark, [.2, .56, .1], .015, .09, .015, .005);                                                                // antenna base
  if (hi) U.push(limb([.2, .56, .1], [.19, .78, .06], .006, .004, 0x111111, 5));
  if (heavy) for (const s of [-1, 1]) { U.push(bake(HALF, plate, [s * .27, .6, 0], [0, 0, -s * .5], [.14, .09, .15])); rb(U, vest, [s * .29, .53, 0], .05, .06, .12, .015); }
  // neck + collar, backpack, bedroll
  U.push(limb([0, .6, 0], [0, .69, .005], .052, .046, skin, 10)); U.push(bake(latheGeo([[.075, .6], [.085, .64], [.065, .69]], 12), solid(T.cloth2), [0, 0, 0], [0, 0, 0], [1, 1, .9]));
  rb(U, vest, [0, .42, -.24], .3, .36, .13, .045); rb(U, vest, [.17, .33, -.24], .06, .16, .1, .02); rb(U, vest, [-.17, .33, -.24], .06, .16, .1, .02);
  U.push(bake(capsuleGeo(.26, .06, .06, hi ? 10 : 5), solid(T.cloth2), [-.13, .63, -.26], [0, 0, -Math.PI / 2]));
  // shoulders + arms in rifle hold (character left = +X)
  const shR = [-.225, .56, 0], elR = [-.2, .36, .17], wrR = [-.06, .46, .38];
  const shL = [.225, .56, 0], elL = [.21, .4, .25], wrL = [.07, .47, .48];
  for (const [sh, el, wr, s] of [[shR, elR, wrR, -1], [shL, elL, wrL, 1]]) {
    ell(U, shirt, sh, [.068, .07, .07]);
    U.push(limb(sh, el, .058, .05, shirt, 12)); U.push(limb(el, wr, .05, .038, shirt, 12));
    ell(U, plate, el, [.06, .06, .06]);                                                                         // elbow pad
    rb(U, glove, [wr[0], wr[1] - .005, wr[2] + .01], .078, .062, .095, .026);                                    // glove
    if (hi) U.push(limb([wr[0] + s * .02, wr[1] + .02, wr[2] + .03], [wr[0] + s * .005, wr[1] + .045, wr[2] + .08], .016, .013, glove, 6));  // thumb
    if (hi) for (let i = 0; i < 3; i++) U.push(limb([wr[0] - s * .03 + i * s * .005, wr[1] - .03, wr[2] + .035 - i * .02], [wr[0] - s * .04, wr[1] - .06, wr[2] + .045 - i * .02], .011, .009, glove, 5));
  }
  // ---------------- weapon ----------------
  const gx = -.02, gy = .52;
  const bar = (z0, z1, r, y = gy, c = 0x15181a) => U.push(bake(new THREE.CylinderGeometry(r, r, z1 - z0, hi ? 8 : 5), dark, [gx, y, (z0 + z1) / 2], [Math.PI / 2, 0, 0]));
  const rail = (z0, z1, y) => { if (!hi) return; for (let z = z0; z < z1; z += .028) rb(U, metal, [gx, y, z], .028, .01, .014, .003, [0, 0, 0]); };
  if (key === 'rifleman') {
    rb(U, metal, [gx, gy + .005, .40], .052, .085, .30, .014); rail(.28, .56, gy + .058);
    rb(U, solid(0x2a2e30), [gx, gy + .005, .68], .062, .07, .27, .022);                                            // handguard
    if (hi) for (let i = 0; i < 4; i++) rb(U, dark, [gx + .033, gy + .005, .6 + i * .06], .004, .03, .03, .002);          // vents
    rb(U, solid(0x1d2123), [gx, gy - .012, .17], .042, .09, .2, .016, [.03, 0, 0]); rb(U, dark, [gx, gy - .02, .065], .046, .115, .03, .012);   // stock + pad
    rb(U, dark, [gx, gy - .095, .32], .036, .11, .048, .014, [.35, 0, 0]);                                           // grip
    [[.44, 0], [.38, .1], [.325, .22]].forEach(([y, a], i) => rb(U, dark, [gx, .45 - i * .06, .49 + i * .014], .04, .075, .07, .012, [-a * .5, 0, 0]));   // curved mag
    bar(.8, 1.0, .0115); bar(.84, .9, .017); cyl(U, dark, [gx, gy, 1.045], .019, .017, .075, [Math.PI / 2, 0, 0], 10);   // barrel, gas block, flash hider
    cyl(U, dark, [gx, gy + .105, .44], .026, .026, .17, [Math.PI / 2, 0, 0]);                                          // optic tube
    cyl(U, solid(0x2c5a72), [gx, gy + .105, .527], .022, .022, .008, [Math.PI / 2, 0, 0]); rb(U, metal, [gx, gy + .065, .44], .03, .03, .06, .008);
    rb(U, dark, [gx + .04, gy + .01, .78], .022, .022, .07, .007);                                                   // light
    T.muz = 1.09;
  } else if (heavy) {
    rb(U, metal, [gx, gy, .42], .075, .1, .38, .02); rail(.25, .58, gy + .062);
    rb(U, solid(0x2a2e30), [gx, gy + .005, .76], .08, .085, .28, .028); if (hi) for (let i = 0; i < 5; i++) cyl(U, dark, [gx + .041, gy + .01, .66 + i * .05], .012, .012, .01, [0, 0, Math.PI / 2], 8);
    rb(U, solid(0x1d2123), [gx, gy - .01, .12], .05, .11, .24, .02); rb(U, dark, [gx, gy - .015, -.005], .055, .13, .03, .012);
    rb(U, dark, [gx, gy - .1, .32], .04, .11, .05, .014, [.35, 0, 0]);
    rb(U, solid(0x4a4a34), [gx, .34, .5], .13, .15, .17, .025); rb(U, solid(0xb08a3a), [gx, .34, .5], .115, .125, .152, .02);   // ammo box
    if (hi) for (let i = 0; i < 5; i++) rb(U, solid(0xb08a3a), [gx, .42 + i * .022, .5 + i * .012 - .005], .02, .02, .03, .006, [0, 0, 0]);   // feed belt
    bar(.95, 1.28, .018); bar(.95, 1.15, .028); cyl(U, dark, [gx, gy, 1.31], .03, .025, .09, [Math.PI / 2, 0, 0]);
    rb(U, dark, [gx, gy + .075, .3], .02, .05, .16, .006);                                                           // carry handle
    for (const s of [-1, 1]) U.push(limb([gx + s * .01, gy - .01, .95], [gx + s * .09, gy - .13, 1.08], .008, .007, 0x101214, 6));   // bipod
    T.muz = 1.36;
  } else {
    rb(U, metal, [gx, gy, .36], .052, .09, .26, .014); rail(.26, .46, gy + .055);
    rb(U, solid(0x1d2123), [gx, gy - .005, .6], .046, .06, .2, .016);
    rb(U, dark, [gx, gy - .1, .3], .036, .11, .046, .014, [.3, 0, 0]); rb(U, dark, [gx, gy - .15, .44], .034, .19, .05, .01, [.04, 0, 0]);  // straight mag
    U.push(limb([gx + .02, gy, .24], [gx + .02, gy - .03, -.04], .007, .007, 0x0f1112, 5)); U.push(limb([gx - .02, gy, .24], [gx - .02, gy - .03, -.04], .007, .007, 0x0f1112, 5));  // wire stock
    rb(U, dark, [gx, gy - .02, -.06], .05, .1, .02, .008);
    bar(.7, .95, .018); cyl(U, dark, [gx, gy, .98], .024, .024, .2, [Math.PI / 2, 0, 0], 12);                          // suppressor
    rb(U, dark, [gx, gy + .075, .42], .03, .03, .06, .008); rb(U, solid(0x3a1010), [gx, gy + .09, .44], .02, .012, .02, .004);        // red dot
    T.muz = 1.1;
  }
  // ---------------- head (own mesh: headshots + head turn). Built around neck pivot (0,.68,0). ----------------
  const hs = skin;
  ell(H, hs, [0, .745, 0], [.092, .112, .102]);                                       // skull
  ell(H, hs, [0, .69, .028], [.074, .066, .082]);                                     // jaw
  for (const s of [-1, 1]) { ell(H, hs, [s * .057, .715, .068], [.03, .03, .03]); ell(H, hs, [s * .097, .74, -.005], [.013, .032, .022]); ell(H, solid(0x0b0c0d), [s * .033, .745, .097], [.016, .011, .01]); ell(H, hs, [s * .034, .765, .092], [.026, .008, .014]); }
  ell(H, hs, [0, .724, .106], [.014, .024, .026]);                                    // nose
  if (!runner || true) { ell(H, solid(T.mask), [0, .693, .02], [.094, .074, .098]); }   // balaclava / face wrap over jaw + nose bridge
  if (heavy) {
    H.push(bake(HALF, solid(T.helmet), [0, .762, -.005], [0, 0, 0], [.138, .128, .152]));
    for (const s of [-1, 1]) rb(H, solid(T.helmet), [s * .122, .72, -.01], .03, .1, .13, .014);                         // ear/side armour
    ell(H, solid(0xb03020), [0, .752, .1], [.105, .036, .04]);                                                       // visor strip
    rb(H, dark, [0, .79, .15], .04, .045, .035, .01); rb(H, solid(T.helmet), [0, .84, .02], .03, .03, .2, .01);        // NVG mount + rail
    ell(H, solid(T.helmet), [0, .762, .12], [.12, .014, .05]);                                                       // brow guard
    H.push(bake(latheGeo([[.098, .665], [.108, .69], [.095, .73]], 14), solid(T.vest), [0, 0, .01], [0, 0, 0], [1, 1, .9]));   // throat guard
  } else if (runner) {
    H.push(bake(HALF, solid(T.helmet), [0, .775, -.002], [0, 0, 0], [.108, .088, .118]));                              // cap crown
    ell(H, solid(T.helmet), [0, .778, .115], [.098, .008, .082]);                                                      // brim
    rb(H, dark, [0, .746, .1], .19, .045, .04, .018); ell(H, solid(0x20303a), [0, .746, .122], [.085, .02, .01]);      // sunglasses
    ell(H, solid(T.mask), [0, .675, .0], [.1, .05, .102]);                                                           // bandana pulled down
    U.push(limb([-.05, .7, -.06], [-.07, .6, -.1], .012, .02, T.helmet, 6));                                           // bandana tail
  } else {
    H.push(bake(HALF, solid(T.helmet), [0, .768, -.005], [0, 0, 0], [.128, .108, .14]));
    ell(H, solid(T.helmet), [0, .764, -.005], [.138, .011, .152]);                                                    // rim
    for (const s of [-1, 1]) { rb(H, solid(T.helmet), [s * .122, .755, 0], .014, .04, .12, .006); rb(H, dark, [s * .105, .715, .0], .03, .05, .05, .012); }   // rails + ear-pro mounts
    rb(H, dark, [0, .795, .12], .045, .05, .04, .01); cyl(H, dark, [0, .8, .147], .02, .02, .03, [Math.PI / 2, 0, 0], 10);  // NVG mount + tube
    rb(H, dark, [0, .745, .092], .185, .052, .045, .02); ell(H, solid(0x4a6a78), [0, .746, .116], [.082, .019, .01]);       // goggles + lens
    if (hi) for (const s of [-1, 1]) U.push(limb([s * .1, .75, .03], [s * .075, .69, .07], .004, .004, 0x111111, 4));          // chin strap
  }
  // ---------------- legs (hip-joint origin) ----------------
  const LT = [], LS = [];
  ell(LT, pants, [0, 0, 0], [.1, .1, .1]);
  LT.push(limb([0, 0, 0], [0, -.45, 0], .098, .07, pants, 12)); rb(LT, plate, [0, -.45, .068], .1, .105, .055, .026);
  rb(LT, solid(T.vest), [.075, -.07, .02], .05, .13, .11, .018);                                                    // cargo pocket
  LS.push(limb([0, 0, 0], [0, -.4, 0], .066, .052, pants, 12)); ell(LS, pants, [0, -.04, .0], [.072, .06, .075]);
  rb(LS, solid(T.boot, -.5), [0, -.46, -.005], .108, .17, .125, .032);                                                // boot shaft
  rb(LS, solid(T.boot, -.5), [0, -.5, .06], .104, .095, .19, .034); ell(LS, solid(T.boot, -.5), [0, -.5, .13], [.05, .045, .055]);   // toe box
  rb(LS, solid(0x0d0d0e), [0, -.538, .045], .112, .026, .29, .012);                                                  // sole
  ell(LS, solid(0x201c18), [0, -.4, -.015], [.062, .05, .06]);                                                       // cuff
  const upper = mergeColored(U), head = mergeColored(H); head.translate(0, -.68, 0); head.computeBoundingSphere();
  return { upper, head, thigh: mergeColored(LT), shin: mergeColored(LS), muz: T.muz };
}
