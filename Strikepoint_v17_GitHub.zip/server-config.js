// Address of your hosted multiplayer server (no https://). Example: 'strikepoint.onrender.com'
// Leave '' when the game is opened from the server's own web address.
window.STRIKEPOINT_SERVER = '';
