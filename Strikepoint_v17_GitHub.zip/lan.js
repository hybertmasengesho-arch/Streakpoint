// LAN GAME (Blur-style): one tap finds / creates the room on your Wi-Fi. No typing of addresses.
//  - PC:    START_PC_SERVER opens the game with ?lan=1 -> the LAN room is created automatically.
//  - Phone: LAN GAME button -> finds the PC on the same Wi-Fi -> joins the same room.
while (!window.__mp) await new Promise(r => setTimeout(r, 50));
const M = window.__mp, $ = id => document.getElementById(id), Q = new URLSearchParams(location.search);
const PORTS = [3000], PREFIXES = ['192.168.0', '192.168.1', '192.168.2', '192.168.43', '192.168.137', '192.168.100', '10.0.0', '10.0.1', '10.1.1', '172.20.10', '192.168.3', '192.168.10', '192.168.50'];
const servedByGame = () => /^https?:$/.test(location.protocol) && !(location.hostname === 'localhost' && !location.port);
const setMsg = t => { const e = $('mp-err'); if (e) e.textContent = t; };
let busy = false, cancelled = false;

async function ping(host, ms = 650) {
  const c = new AbortController(), t = setTimeout(() => c.abort(), ms);
  try { const r = await fetch(`http://${host}/lan-ping`, { signal: c.signal, cache: 'no-store' }); const j = await r.json(); return j && j.game === 'strikepoint' ? j : null; } catch (e) { return null; } finally { clearTimeout(t); }
}
function ownPrefix() {   // best effort: the phone's own /24 via WebRTC (may be hidden by the browser)
  return new Promise(res => {
    let done = false; const fin = v => { if (!done) { done = true; res(v); } };
    try { const pc = new RTCPeerConnection({ iceServers: [] }); pc.createDataChannel('x');
      pc.onicecandidate = e => { if (!e.candidate) return fin(null); const m = /(\d+\.\d+\.\d+)\.\d+/.exec(e.candidate.candidate); if (m && !/^(0|127)\./.test(m[1])) { fin(m[1]); try { pc.close(); } catch (x) { } } };
      pc.createOffer().then(o => pc.setLocalDescription(o)).catch(() => fin(null)); setTimeout(() => fin(null), 1200);
    } catch (e) { fin(null); }
  });
}
async function discover() {
  let saved = null; try { saved = localStorage.getItem('sp_lan'); } catch (e) { }
  if (saved) { setMsg('Checking the last game…'); if (await ping(saved, 900)) return saved; }
  const own = await ownPrefix(), prefs = [...(own ? [own] : []), ...PREFIXES.filter(p => p !== own)];
  for (const pre of prefs) {
    if (cancelled) return null; setMsg(`Searching Wi-Fi ${pre}.x …`);
    const hosts = []; for (let i = 1; i < 255; i++) for (const p of PORTS) hosts.push(`${pre}.${i}:${p}`);
    let found = null, idx = 0;
    await Promise.all(Array.from({ length: 80 }, async () => { while (!found && !cancelled && idx < hosts.length) { const h = hosts[idx++]; if (await ping(h, 600)) found = h; } }));
    if (found) return found;
  }
  return null;
}
async function runLan() {
  if (busy) return; busy = true; cancelled = false;
  $('start-screen').classList.add('hidden'); $('mp-screen').classList.remove('hidden');
  setMsg('Looking for a Strikepoint game on this Wi-Fi…');
  const addr = servedByGame() ? location.host : await discover();
  busy = false;
  if (!addr) { if (!cancelled) setMsg('No game found. On the PC run START_PC_SERVER (same Wi-Fi), then tap LAN GAME again. Or type the address below.'); return; }
  try { localStorage.setItem('sp_lan', addr); } catch (e) { }
  $('mp-server').value = addr; setMsg('Found it — joining…'); await M.connect('lan');
  if (servedByGame()) { try { const j = await (await fetch('/lan-ping')).json(); showHint(j.ips || [], j.port); } catch (e) { } }
}
function showHint(ips, port) {
  let h = $('lan-hint'); if (!h) { h = document.createElement('p'); h.id = 'lan-hint'; h.style.cssText = 'font-size:12px;opacity:.85;margin:6px 0;line-height:1.4'; const c = $('mp-count'); c && c.parentNode.insertBefore(h, c.nextSibling); }
  h.innerHTML = 'Other devices on this Wi-Fi: open the Strikepoint app and tap <b>LAN GAME</b>' + (ips.length ? '<br>or browse to ' + ips.map(i => `<b>http://${i}:${port}</b>`).join(' / ') : '');
}
// buttons
const mk = (id, txt, cls) => { const b = document.createElement('button'); b.id = id; b.className = cls; b.textContent = txt; return b; };
const open = $('mp-open'); if (open) open.parentNode.insertBefore(mk('lan-open', 'LAN GAME · AUTO WI-FI ▸', 'primary'), open);
const form = $('mp-form'); if (form) form.insertBefore(mk('lan-btn', 'LAN · FIND / CREATE ON WI-FI', 'primary'), form.firstChild);
$('lan-open')?.addEventListener('click', runLan); $('lan-btn')?.addEventListener('click', runLan);
$('mp-back')?.addEventListener('click', () => { cancelled = true; });
// PC launcher opens the page with ?lan=1: create the LAN room automatically once the game is loaded
if (Q.get('lan') === '1') { const t = setInterval(() => { const b = $('mp-open'); if (b && !b.disabled) { clearInterval(t); runLan(); } }, 200); }
