import * as THREE from 'three';
import { clamp, wrapPi, rand, resolveCircle, firstWallHit, firstWallHitInfo, raySphere } from './utils.js';
import { buildWorld, HALF } from './world.js';
import { Nav, Director, Brain } from './ai.js';
import { Net } from './net.js';
import { Vehicle, TyreFX, makeEnv, TYPES } from './vehicles.js';
import { Soldier } from './enemies.js';
import { loadOperator, buildRifleGeo, stride } from './character.js';
import { initAudio, engineUpdate, shot, thud, footstep, sting } from './audio.js';
import { Particles } from './fx.js';
import { loadModels } from './models.js';
import { Cine, makeHeli, lerp3 } from './cine.js';

const $ = id => document.getElementById(id);
const Q = new URLSearchParams(location.search);
const game = $('game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0xcfc6ae);
scene.fog = new THREE.Fog(0xc9c4b2, 45, 190);
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.08, 360);
camera.rotation.order = 'YXZ'; scene.add(camera);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
const MOBILE = matchMedia('(pointer:coarse)').matches; const PR = () => Math.min(devicePixelRatio, MOBILE ? 1.5 : 1.8);
renderer.setPixelRatio(PR()); renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true; renderer.shadowMap.autoUpdate = false; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.02;
game.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xdfe8f2, 0x6a5538, 1.35));
const sun = new THREE.DirectionalLight(0xffd29a, 3.6);
sun.castShadow = true; sun.shadow.mapSize.set(MOBILE ? 1024 : 2048, MOBILE ? 1024 : 2048); sun.shadow.bias = -.0006; sun.shadow.normalBias = .03;
const sc = sun.shadow.camera; sc.left = sc.bottom = -26; sc.right = sc.top = 26; sc.near = 1; sc.far = 90;
scene.add(sun, sun.target);

const world = buildWorld(scene);
const env = makeEnv(renderer);
if (env) { scene.environment = env; scene.environmentIntensity = .38; }
{ const fxd = document.createElement('div'); fxd.id = 'fx'; renderer.domElement.after(fxd); }
const fx = new TyreFX(scene);
const PI = Math.PI;
const VEH = [   // [type, {x,z,rot,color}] — motor pool (spawn) first, then field vehicles, then wrecks
  ['sedan', { x: -16, z: 60, rot: PI + .1, color: 0x8e0d14 }], ['jeep', { x: -10, z: 60.5, rot: PI - .12, color: 0x4a5a34 }], ['pickup', { x: 10, z: 60, rot: PI + .1, color: 0x1f4f8f }],
  ['sport', { x: 16, z: 60.5, rot: PI - .1, color: 0xe0a21a }], ['suv', { x: -14, z: 65, rot: PI, color: 0xe8e8e4 }], ['jeep', { x: 14, z: 65, rot: PI + .05, color: 0x9a8860 }],
  ['jeep', { x: -7, z: -20, rot: PI / 2, color: 0x4a5a34 }], ['pickup', { x: 7, z: 34, rot: 0, color: 0xc9651a }], ['sedan', { x: -7, z: 18, rot: .05, color: 0x1a3f9a }],
  ['suv', { x: 7, z: -26, rot: PI, color: 0x22262a }], ['jeep', { x: -46, z: -30, rot: 0, color: 0x9a8860 }], ['pickup', { x: 46, z: 30, rot: PI, color: 0x1f4f8f }], ['sport', { x: 22, z: 6.5, rot: PI / 2, color: 0x8e0d14 }],
  ['wreck', { x: -18, z: 2.5, rot: .4 }], ['wreck', { x: 24, z: -3, rot: 1.2 }], ['wreck', { x: 2.5, z: -38, rot: .5 }], ['wreck', { x: 40, z: -20, rot: 1.6 }], ['wreck', { x: -40, z: 14, rot: -.3 }], ['wreck', { x: 62, z: 56, rot: .8 }],
  // ---- v13 outer-zone vehicles (axis + ring roads) ----
  ['jeep', { x: 80, z: 2.5, rot: PI / 2, color: 0x4a5a34 }], ['pickup', { x: -80, z: -2.5, rot: -PI / 2, color: 0xc9651a }], ['suv', { x: 3, z: -88, rot: 0, color: 0x22262a }], ['sedan', { x: -3, z: 90, rot: PI, color: 0x1a3f9a }],
  ['sport', { x: 98, z: -40, rot: 0, color: 0xe0a21a }], ['jeep', { x: -98, z: 40, rot: PI, color: 0x9a8860 }], ['pickup', { x: 40, z: 98, rot: PI / 2, color: 0x1f4f8f }], ['sedan', { x: -40, z: -98, rot: -PI / 2, color: 0x8e0d14 }],
  ['wreck', { x: 70, z: -60, rot: .6 }], ['wreck', { x: -75, z: 55, rot: 2.1 }], ['wreck', { x: 20, z: 80, rot: 1.1 }], ['wreck', { x: -30, z: -78, rot: -.7 }],
];
await loadModels(p => { const b = document.querySelector('.loadbar i'); if (b) b.style.width = (10 + p * 80) + '%'; });
const vehicles = VEH.map(([t, o]) => new Vehicle(t, scene, env, o));
const nav = new Nav(world.colliders, HALF); for (const v of vehicles) for (const c of v.circles()) nav.blockCircle(c[0], c[1], c[2] * .8);
const director = new Director(world, nav);
const parts = new Particles(scene);
const heli = makeHeli(); scene.add(heli);
const cineUI = { on(v) { document.body.classList.toggle('cine', v); }, caption(t, big, cls) { const c = $('cap'); c.className = (big ? 'big ' : '') + (cls || ''); c.textContent = t; c.style.animation = 'none'; void c.offsetWidth; c.style.animation = ''; } };
const cine = new Cine(camera, cineUI);
const rings = []; const _rv = new THREE.Vector3();
const rv = r => _rv.set(rand(-r, r), rand(0, r), rand(-r, r)).clone();
function shockRing(x, z) { const m = new THREE.Mesh(new THREE.RingGeometry(.85, 1, 40).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffd9a0, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); m.position.set(x, .08, z); scene.add(m); rings.push({ m, t: 0 }); }
function updateRings(dt) { for (let i = rings.length - 1; i >= 0; i--) { const r = rings[i]; r.t += dt; const k = r.t / .55; r.m.scale.setScalar(1 + k * 9); r.m.material.opacity = Math.max(0, .8 * (1 - k)); if (k >= 1) { scene.remove(r.m); r.m.geometry.dispose(); r.m.material.dispose(); rings.splice(i, 1); } } }

// ---------------- game state ----------------
let yaw = 0, pitch = 0, started = false, paused = false, health = 100, ammo = 30, reserve = 120, kills = 0, reloading = false;
const MAG = 30, WALK = 3.4, EYE = 1.72, LIM = HALF - 2.5; let TOTAL = 20;
const keys = {}; let joy = { x: 0, y: 0 }, velocityY = 0, grounded = true, fireHeld = false, fireCd = 0, lastShot = -9, lookT = -9;
const player = { x: 0, y: EYE, z: 60 };
let camMode = Q.get('cam') === 'fp' ? 'fp' : 'tp';
let timeScale = 1, finaleStarted = false, introSeen = false, heliBeat = 0, reloadStart = -9, kickA = 0, flinchA = 0, deadAnim = false, deadT = 0, coverUp = 0, eyeOff = 0, crouchOn = false, autoCrouch = false, zoomOn = false, zoomHold = false, crouchW = 0, zoomW = 0, inCover = false, coverN = null, coverLow = false, lastHurt = -99, noiseT = 0, radarT = 0, pvx = 0, pvz = 0, sprintToggle = false, runW = 0, sprintW = 0, airW = 0, relS = 0, landDip = 0, recoil = 0, driving = null, nearVeh = null, time = 0, tw = 0, sw = 0, lastSpd = 1.4, aimW = 0, camShake = 0;
const enemies = [];
let MP = false, mpHost = false, netLost = false;   // multiplayer (co-op) state
const clock = new THREE.Clock();

// ---------------- operator (your FBX character) ----------------
let op = null;
const vm = new THREE.Group(); // first-person viewmodel
{ const m = new THREE.Mesh(buildRifleGeo(), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .6, metalness: .4 })); m.scale.setScalar(.4); vm.add(m);
  const f = new THREE.Mesh(new THREE.PlaneGeometry(.3, .3), new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false })); f.position.set(0, .04, .5); f.visible = false; vm.add(f); vm.userData.flash = f;
  vm.rotation.y = Math.PI + .06; vm.position.set(.18, -.17, -.45); camera.add(vm); }
async function loadOp() {
  try {
    op = await loadOperator(p => { const b = document.querySelector('.loadbar i'); if (b) b.style.width = (10 + p * 90) + '%'; });
    scene.add(op.root); op.root.position.set(player.x, 0, player.z);
  } catch (e) { console.error(e); op = null; camMode = 'fp'; }
}

// ---------------- HUD ----------------
function updateHud() { $('health').textContent = Math.max(0, Math.ceil(health)); $('healthbar').style.width = Math.max(0, health) + '%'; $('ammo').innerHTML = `${ammo} <small>/ ${reserve}</small>`; $('kills').textContent = String(MP ? enemies.reduce((n, e) => n + (e.alive ? 0 : 1), 0) : kills).padStart(2, '0') + '/' + TOTAL; }
function showMessage(t) { $('message').textContent = t; $('message').style.opacity = '1'; clearTimeout(showMessage.timer); showMessage.timer = setTimeout(() => $('message').style.opacity = '.65', 1500); }
function hitFlash() { $('damage').style.boxShadow = 'inset 0 0 90px 25px #d52b2b88'; setTimeout(() => $('damage').style.boxShadow = 'inset 0 0 0 0 #d52b2b', 180); }
function hitMarker(kill) { const h = $('hitmarker'); h.style.color = kill ? '#ff4a3a' : '#f0a52b'; h.style.opacity = '1'; h.style.transform = 'translate(-50%,-50%) scale(1)'; setTimeout(() => { h.style.opacity = '0'; h.style.transform = 'translate(-50%,-50%) scale(.5)'; }, 140); }

// ---------------- effects: tracers + dust ----------------
const trGeo = new THREE.BoxGeometry(1, 1, 1), trMat = new THREE.MeshBasicMaterial({ color: 0xffe3a0, transparent: true, opacity: .9, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
const tracers = Array.from({ length: 40 }, () => { const m = new THREE.Mesh(trGeo, trMat); m.visible = false; m.userData.t = 0; scene.add(m); return m; });
let trI = 0;
function tracer(a, b, w = .025) {
  const m = tracers[trI]; trI = (trI + 1) % tracers.length; const len = a.distanceTo(b); if (len < .2) return;
  m.position.copy(a).add(b).multiplyScalar(.5); m.lookAt(b); m.scale.set(w, w, len); m.userData.t = .07; m.userData.w = w; m.visible = true;
}
const dustTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 2, 32, 32, 30); g.addColorStop(0, 'rgba(230,215,185,.9)'); g.addColorStop(1, 'rgba(230,215,185,0)'); x.fillStyle = g; x.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
const puffs = Array.from({ length: 20 }, () => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: dustTex, transparent: true, depthWrite: false, opacity: 0 })); s.visible = false; s.userData.t = 0; scene.add(s); return s; });
let pfI = 0;
function puff(p, big = 1, red = false) { const s = puffs[pfI]; pfI = (pfI + 1) % puffs.length; s.position.copy(p); s.userData.t = .5; s.userData.big = big; s.material.color.set(red ? 0xff6a50 : 0xffffff); s.visible = true; }
const decalTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 32; const x = c.getContext('2d'), gr = x.createRadialGradient(16, 16, 1, 16, 16, 15); gr.addColorStop(0, 'rgba(10,8,6,.95)'); gr.addColorStop(.35, 'rgba(25,20,15,.8)'); gr.addColorStop(1, 'rgba(25,20,15,0)'); x.fillStyle = gr; x.fillRect(0, 0, 32, 32); return new THREE.CanvasTexture(c); })();
const decals = Array.from({ length: 36 }, () => { const m = new THREE.Mesh(new THREE.PlaneGeometry(.2, .2), new THREE.MeshBasicMaterial({ map: decalTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3 })); m.visible = false; scene.add(m); return m; });
let dcI = 0;
function decal(p, n) { const m = decals[dcI++ % decals.length]; m.position.copy(p).addScaledVector(n, .015); m.lookAt(p.x + n.x, p.y + n.y, p.z + n.z); m.rotateZ(Math.random() * 6); m.visible = true; }
function updateFx(dt) {
  parts.update(dt); updateRings(dt);
  for (const m of tracers) if (m.visible) { m.userData.t -= dt; if (m.userData.t <= 0) m.visible = false; else { const k = m.userData.t / .07; m.scale.x = m.scale.y = m.userData.w * k; } }
  for (const s of puffs) if (s.visible) { s.userData.t -= dt; const k = s.userData.t / .5; if (k <= 0) { s.visible = false; continue; } s.scale.setScalar((1 - k) * 1.3 * s.userData.big + .2); s.material.opacity = k * .7; s.position.y += dt * .5; }
  fx.update(dt);
}

// ---------------- helpers ----------------
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3(), _d = new THREE.Vector3();
const raycaster = new THREE.Raycaster();
function blocked(x, z, r = .9) {
  if (resolveCircle(x, z, r, world.colliders, 0).hit) return true;
  for (const v of vehicles) for (const [qx, qz, qr] of v.circles()) if (Math.hypot(x - qx, z - qz) < qr + r) return true;
  return false;
}
function targetPoint(out) { if (driving) return out.set(driving.x, 1.1, driving.z); return out.set(player.x, player.y - .45 + eyeOff * .8, player.z); }
function nearestVehicle() {
  let best = null, bd = 2.6;
  for (const v of vehicles) { if (v.wreck) continue; for (const [qx, qz, qr] of v.circles()) { const d = Math.hypot(player.x - qx, player.z - qz) - qr; if (d < bd) { bd = d; best = v; } } }
  return best;
}
const SQUADS = [   // squads: members spawn near `at`, then patrol the loop; each squad shares alerts
  { types: ['heavy', 'rifleman', 'rifleman', 'rifleman', 'heavy'], at: [[-6, -55.5], [6, -55.5], [-11, -56], [11, -56], [0, -55]], patrol: [[-10, -54], [10, -54], [22, -58], [22, -66], [-22, -66], [-22, -58]] },
  { types: ['rifleman', 'rifleman', 'runner'], at: [[18, -8], [22, -8], [26, -8]], patrol: [[10, -8], [36, -8], [36, -24], [20, -24], [10, -24]] },
  { types: ['rifleman', 'rifleman', 'runner'], at: [[18, 9], [22, 9], [26, 9]], patrol: [[10, 10], [36, 10], [36, 30], [22, 28], [10, 28]] },
  { types: ['heavy', 'rifleman', 'rifleman'], at: [[-20, -7], [-24, -7], [-28, -7]], patrol: [[-10, -8], [-36, -8], [-36, -26], [-10, -26]] },
  { types: ['rifleman', 'runner'], at: [[48, -6], [52, -6]], patrol: [[48, -6], [64, -6], [64, -24], [46, -26]] },
  { types: ['rifleman', 'rifleman'], at: [[-50, 40], [-46, 40]], patrol: [[-50, 40], [-30, 40], [-30, 56], [-46, 56]] },
  { types: ['runner', 'runner'], at: [[0, -20], [2, -22]], patrol: [[0, -20], [0, 28]] },
  // ---- outer-zone squads (v13): used in multiplayer, 7 hostiles per player (5 players = 35) ----
  { types: ['heavy', 'rifleman', 'rifleman', 'rifleman'], at: [[76, -76], [80, -74], [74, -82], [82, -82]], patrol: [[76, -76], [90, -76], [90, -88], [72, -88], [70, -70]] },
  { types: ['heavy', 'rifleman', 'rifleman', 'runner'], at: [[-76, -76], [-80, -74], [-74, -82], [-82, -82]], patrol: [[-76, -76], [-90, -76], [-90, -88], [-72, -88], [-70, -70]] },
  { types: ['rifleman', 'rifleman', 'rifleman', 'runner'], at: [[76, 76], [80, 74], [74, 82], [82, 82]], patrol: [[76, 76], [90, 76], [90, 88], [72, 88], [70, 70]] },
  { types: ['rifleman', 'rifleman', 'runner'], at: [[-76, 76], [-80, 74], [-74, 82]], patrol: [[-76, 76], [-90, 76], [-90, 88], [-72, 88], [-70, 70]] },
];
function spawnEnemies() {
  let sq = 0, made = 0; const limit = MP ? Math.max(1, net.n || 35) : 20;   // solo = first 20 (original squads); co-op = 7 per player from the server (max 35)
  for (const S of SQUADS) {
    if (made >= limit) break;
    S.types.forEach((k, i) => { if (made >= limit) return; made++; let [x, z] = S.at[i]; const c = nav.nearestFree(nav.idx(x, z)); if (c >= 0) { x = nav.cx(c); z = nav.cz(c); } enemies.push(mkEnemy(k, scene, x, z, { squad: sq, dir: director, patrol: S.patrol.map(p => { const f = nav.nearestFree(nav.idx(p[0], p[1])); return f >= 0 ? [nav.cx(f), nav.cz(f)] : p; }) })); });
    sq++;
  }
  director.soldiers = enemies; TOTAL = enemies.length;
  if (MP && !mpHost) for (const e of enemies) e.brain = stubBrain();
}
function mkEnemy(k, sc, x, z, o) { const e = new Soldier(k, sc, x, z, o); e._patrol = o.patrol; return e; }
// ---------------- shooting ----------------
function muzzleWorld(out) {
  if (op && camMode === 'tp' && !driving) { op.flash.updateWorldMatrix(true, false); return op.flash.getWorldPosition(out); }
  const f = vm.userData.flash; f.updateWorldMatrix(true, false); return f.getWorldPosition(out);
}
function shoot() {
  if (!started || paused || reloading || driving) return;
  if (ammo <= 0) { showMessage('MAGAZINE EMPTY — RELOAD'); fireHeld = false; return; }
  ammo--; updateHud(); lastShot = time; kickA = 1; rumble(.15, .1, 40); shot(.22, 2400, .08);
  recoil = Math.min(.12, recoil + .012);
  // muzzle flash on whichever weapon is visible
  const fl = (op && camMode === 'tp') ? op.flash : vm.userData.flash; fl.visible = true; fl.rotation.z = Math.random() * 3; setTimeout(() => fl.visible = false, 45);
  vm.position.z = -.37;
  // aim ray from the camera through the crosshair
  camera.getWorldDirection(_b); _a.copy(camera.position);
  if (camMode === 'tp' && op) _a.addScaledVector(_b, camDistNow + .3);
  raycaster.set(_a, _b); raycaster.far = 150;
  const meshes = []; for (const e of enemies) if (e.alive) meshes.push(...e.hitMeshes);
  const hits = raycaster.intersectObjects(meshes, false);
  let tEnemy = hits.length ? hits[0].distance : Infinity;
  const wInfo = firstWallHitInfo(_a.x, _a.y, _a.z, _b.x, _b.y, _b.z, world.colliders, 150); let tWall = wInfo.t;
  let tVeh = Infinity; for (const v of vehicles) for (const [qx, qz, qr] of v.circles()) tVeh = Math.min(tVeh, raySphere(_a.x, _a.y, _a.z, _b.x, _b.y, _b.z, qx, .85, qz, qr * .85));
  let tBar = Infinity, barHit = null; for (const b of world.barrels) if (b.alive) { const t = raySphere(_a.x, _a.y, _a.z, _b.x, _b.y, _b.z, b.x, .5, b.z, .55); if (t < tBar) { tBar = t; barHit = b; } }
  const tEnd = Math.min(tEnemy, tWall, tVeh, tBar, 120);
  _c.copy(_a).addScaledVector(_b, tEnd);
  muzzleWorld(_d); tracer(_d, _c); mpShot(_d, _c);
  parts.spawn({ p: _d.clone(), v: [rand(-.3, .3), .5, rand(-.3, .3)], life: .9, s0: .08, s1: .45, color: 0x9a9a9a, op: .3, drag: 1.2 });
  { const rgt = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion); parts.casing(_d.clone().addScaledVector(_b, -.45), rgt.multiplyScalar(2 + Math.random() * 1.4).add(new THREE.Vector3(rand(-.3, .3), 1.6 + Math.random(), rand(-.3, .3)))); }
  if (barHit && tBar <= tEnemy && tBar <= tWall && tBar <= tVeh) { explode(barHit, MP ? net.id : 0); mpBarrel(barHit); }
  else if (tEnemy <= tWall && tEnemy <= tVeh && hits.length) {
    const h = hits[0], e = h.object.userData.enemy, head = h.object.userData.part === 'head' || (h.object.userData.ext && h.point.y - e.root.position.y > 1.55 * e.root.scale.y);
    const dead = hitEnemy(e, 34, head); hitMarker(dead); puff(_c, .6, true); for (let i = 0; i < 5; i++) parts.spawn({ p: _c.clone(), v: [rand(-1.5, 1.5), rand(.5, 2.5), rand(-1.5, 1.5)], life: .45, s0: .06, s1: .18, color: 0xa01010, op: .9, grav: 9, drag: .5 }); shot(.08, 900, .05);
    if (dead) { kills++; reserve += 15; health = Math.min(100, health + 5); updateHud(); showMessage(head ? 'HEADSHOT' : 'HOSTILE ELIMINATED'); if (head && !MP) timeScale = .3; checkWin(); }
    else if (head) showMessage('HEADSHOT');
  } else if (tEnd < 120) { puff(_c, 1); if (wInfo.c && tWall <= tVeh) { const c = wInfo.c, d = [Math.abs(_c.x - c.minX), Math.abs(_c.x - c.maxX), Math.abs(_c.z - c.minZ), Math.abs(_c.z - c.maxZ), Math.abs(_c.y - c.h)], k = d.indexOf(Math.min(...d)); decal(_c, _d.set(k === 0 ? -1 : k === 1 ? 1 : 0, k === 4 ? 1 : 0, k === 2 ? -1 : k === 3 ? 1 : 0)); } }
  director.makeNoise(player.x, player.z, 58);
  if (ammo === 0 && reserve > 0) setTimeout(reload, 250);
}
function reload() {
  if (reloading || ammo === MAG || reserve <= 0 || !started || paused || driving) return;
  reloading = true; reloadStart = time; showMessage('RELOADING…');
  setTimeout(() => { if (!started) { reloading = false; return; } const n = Math.min(MAG - ammo, reserve); ammo += n; reserve -= n; reloading = false; updateHud(); showMessage('READY'); }, 1150);
}
function damagePlayer(amount) {
  if (deadAnim || cine.active) return; flinchA = 1; rumble(.5, .4, 120); lastHurt = time; health = Math.max(0, health - amount); updateHud(); hitFlash();
  if (health <= 0) { document.body.classList.add('dead'); deadAnim = true; deadT = 0; fireHeld = false; if (MP) { showMessage('YOU ARE DOWN — RESPAWNING'); setTimeout(respawnLocal, 5000); return; } setTimeout(() => { paused = true; $('pause-screen').classList.remove('hidden'); $('pause-screen').querySelector('h1').textContent = 'MISSION FAILED'; $('pause-screen').querySelector('.eyebrow').textContent = 'OPERATOR DOWN'; $('resume').textContent = 'TRY AGAIN'; }, 1300); }
}
function checkWin() { const done = MP ? enemies.every(e => !e.alive) : kills >= TOTAL; if (MP && !mpHost) return; if (done && !finaleStarted) { finaleStarted = true; timeScale = .25; setTimeout(playOutro, 1100); if (MP) net.all({ k: 'win' }); } }
function explode(b, by) {
  if (!b.alive) return; b.alive = false; b.mesh.visible = false; const ci = world.colliders.indexOf(b.col); if (ci >= 0) world.colliders.splice(ci, 1);
  const P0 = new THREE.Vector3(b.x, .6, b.z), at = driving ? new THREE.Vector3(driving.x, 0, driving.z) : new THREE.Vector3(player.x, 0, player.z), dP = Math.hypot(at.x - b.x, at.z - b.z);
  for (let i = 0; i < 12; i++) parts.spawn({ p: P0.clone().add(rv(.4)), v: [rand(-3, 3), rand(2, 7), rand(-3, 3)], life: rand(.5, .9), s0: .8, s1: rand(3.5, 5.5), color: i % 2 ? 0xffa030 : 0xff6a10, add: true, op: .95, drag: 2.2 });
  parts.spawn({ p: P0.clone(), v: [0, 0, 0], life: .25, s0: 2, s1: 10, color: 0xfff0c0, add: true, op: 1, drag: 0 });
  for (let i = 0; i < 16; i++) parts.spawn({ p: P0.clone().add(rv(.5)), v: [rand(-1, 1), rand(2, 5), rand(-1, 1)], life: rand(2.2, 3.8), s0: 1, s1: rand(4, 7), color: 0x2a2a2a, op: .55, drag: .7 });
  for (let i = 0; i < 24; i++) parts.spawn({ p: P0.clone(), v: [rand(-9, 9), rand(3, 12), rand(-9, 9)], life: rand(.5, 1.1), s0: .14, s1: .04, color: 0xffc060, add: true, op: 1, grav: 14, drag: .2 });
  for (let i = 0; i < 4; i++) parts.spawn({ p: P0.clone().add(rv(.6)), v: [0, .6, 0], life: 3.2, s0: 1.2, s1: 1.8, color: 0xff7a18, add: true, op: .5, drag: 1 });
  shockRing(b.x, b.z); shot(.9, 320, .7); thud(.7); director.makeNoise(b.x, b.z, 85);
  camShake = Math.max(camShake, clamp(1.5 - dP / 22, 0, 1.3)); { const f = $('boom'); f.style.transition = 'none'; f.style.opacity = clamp(1.1 - dP / 28, 0, .85); void f.offsetWidth; f.style.transition = 'opacity .7s'; f.style.opacity = 0; }
  if (!MP || mpHost) for (const e of enemies) if (e.alive) { const d = Math.hypot(e.root.position.x - b.x, e.root.position.z - b.z); if (d < 9 && e.hit(280 * (1 - d / 9) + 20, false, player)) creditKill(by, 'EXPLOSIVE KILL'); }
  if (dP < 8) damagePlayer(85 * (1 - dP / 8));
  for (const v of vehicles) { if (v.wreck) continue; const d = Math.hypot(v.x - b.x, v.z - b.z); if (d < 10 && d > .1) { v.vx += (v.x - b.x) / d * 9 * (1 - d / 10); v.vz += (v.z - b.z) / d * 9 * (1 - d / 10); } }
  for (const o of world.barrels) if (o.alive && Math.hypot(o.x - b.x, o.z - b.z) < 4.5) setTimeout(() => explode(o, by), 120 + Math.random() * 220);
}
// ---------------- short movies ----------------
let heliP = new THREE.Vector3();
function heliPlace(p, look, dt) { const d = look.clone().sub(heli.position); heli.position.copy(p); if (d.lengthSq() > .01) heli.rotation.y = Math.atan2(look.x - p.x, look.z - p.z); }
const HP = [[-30, 26, -88], [0, 17, -50], [0, 12, -5], [-3, 14, 45], [-3, 30, 110]];
function heliAt(u) { u = clamp(u, 0, .9999); const f = u * (HP.length - 1), i = Math.floor(f), k = f - i, a = HP[i], b = HP[i + 1], p = new THREE.Vector3(a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k); heli.rotation.y = Math.atan2(b[0] - a[0], b[2] - a[2]); heli.rotation.x = .08; heli.position.copy(p); heliP.copy(p); }
function playIntro() {
  let t = 0; const T = 12.5, tick = (e, dt) => { t += dt; heliAt(t / T); };
  cine.play([
    { dur: 4.2, cap: 'OPERATION DUSTLINE', big: true, start: () => { heli.visible = true; t = 0; }, cam: e => ({ pos: lerp3([-46, 30, -84], [12, 20, -66], e), look: [0, 4, -60], fov: 55 }), tick },
    { dur: 4.2, cap: '20 hostiles. One operator.', cam: e => ({ pos: lerp3([12, 9, -30], [12, 7, 22], e), look: [heliP.x, heliP.y - 1, heliP.z], fov: 60 }), tick },
    { dur: 4.1, cap: 'Find a vehicle. Use cover. Eliminate them all.', cam: e => ({ pos: lerp3([-10, 12, 30], [1.2, 2.6, 64], e), look: lerp3([heliP.x, heliP.y, heliP.z], [0, 1.5, 58], Math.min(1, e * 1.6)), fov: 60 + 10 * e }), tick, end: () => { heli.visible = false; camera.fov = 70; camera.updateProjectionMatrix(); } },
  ], () => { heli.visible = false; camera.fov = 70; camera.updateProjectionMatrix(); });
}
function playOutro() {
  if (!started) return; const px = driving ? driving.x : player.x, pz = driving ? driving.z : player.z, from = new THREE.Vector3(px - 70, 38, pz - 70), hov = new THREE.Vector3(px + 7, 8, pz + 6); let u = 0;
  const tick = (e, dt) => { u = Math.min(1, u + dt / 7); const k = u * u * (3 - 2 * u); heli.position.lerpVectors(from, hov, k); heli.rotation.y = Math.atan2(hov.x - from.x, hov.z - from.z) * (1 - k) + Math.atan2(px - hov.x, pz - hov.z) * k; heli.rotation.x = .12 * (1 - k); if (k > .5 && Math.random() < .8) parts.spawn({ p: new THREE.Vector3(px + 7 + rand(-7, 7), .2, pz + 6 + rand(-7, 7)), v: [rand(-3, 3), rand(.2, .8), rand(-3, 3)], life: 1.2, s0: .6, s1: 2.4, color: 0xcbb88a, op: .35, drag: 1.2 }); };
  cine.play([
    { dur: 5.5, cap: 'AREA SECURED', big: true, start: () => { heli.visible = true; heli.position.copy(from); }, cam: e => { const a = -.6 + e * 1.9, r = 6 + e * 3; return { pos: [px + Math.sin(a) * r, 1.6 + e * 1.8, pz + Math.cos(a) * r], look: [px, 1.3, pz], fov: 52 }; }, tick },
    { dur: 4, cap: 'Extraction inbound.', cam: e => ({ pos: lerp3([px - 6, 2.2, pz + 7], [px - 9, 3.2, pz + 10], e), look: [heli.position.x, heli.position.y, heli.position.z], fov: 58 }), tick },
  ], () => { heli.visible = false; camera.fov = 70; camera.updateProjectionMatrix(); endGame(); });
}
// ---------------- stealth awareness: overhead icons, HUD chip, "spotted" / "lost them" clips ----------------
const mkIcon = (ch, col) => { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d'); x.fillStyle = 'rgba(10,14,20,.8)'; x.beginPath(); x.arc(32, 32, 28, 0, 7); x.fill(); x.lineWidth = 4; x.strokeStyle = col; x.stroke(); x.fillStyle = col; x.font = 'bold 40px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(ch, 32, 35); return new THREE.CanvasTexture(c); };
const iconQ = mkIcon('?', '#f0a52b'), iconE = mkIcon('!', '#ff3b30');
function ensureIcon(e) { if (!e.icon) { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: iconQ, transparent: true, depthTest: false, depthWrite: false })); s.position.y = 2.5; s.renderOrder = 20; s.visible = false; e.root.add(s); e.icon = s; } return e.icon; }
let visState = 'unseen', heatActive = false, calmT = 0, spotCd = 0;
function updateAwareness(dt) {
  let sees = 0, alert = 0, maxAw = 0, spotter = null;
  for (const e of enemies) {
    if (!e.alive) { if (e.icon) e.icon.visible = false; continue; }
    const b = e.brain, st = b.state, ic = ensureIcon(e), d = Math.hypot(e.root.position.x - player.x, e.root.position.z - player.z);
    const isE = st === 'combat' || st === 'retreat' || st === 'evade', isQ = !isE && (st === 'invest' || st === 'search' || b.awareness > .25);
    if (isE && b.sees) sees++; if (isE || isQ) alert++; maxAw = Math.max(maxAw, isE ? 1 : Math.min(1, b.awareness));
    if (d < 75 && (isE || isQ) && !cine.active) { ic.visible = true; ic.material.map = isE ? iconE : iconQ; const sc = isE ? .72 * (1 + .15 * Math.sin(time * 10)) : .34 + .32 * Math.min(1, b.awareness); ic.scale.set(sc, sc, 1); } else ic.visible = false;
    if (isE && !e._wasE && b.sees && !spotter) spotter = e; e._wasE = isE;
  }
  const state = sees > 0 ? 'spotted' : (alert > 0 ? 'search' : 'unseen');
  if (state !== visState) { visState = state; $('vis').className = state; $('vistxt').textContent = state === 'spotted' ? 'SPOTTED' : state === 'search' ? 'SEARCHING' : 'UNSEEN'; }
  $('visbar').style.width = (state === 'spotted' ? 100 : Math.round(maxAw * 100)) + '%';
  spotCd -= dt; const free = !MP && !cine.active && !deadAnim && !finaleStarted;
  if (state !== 'unseen') { heatActive = true; calmT = 0; } else if (heatActive) { calmT += dt; if (calmT > 3.5 && free) { heatActive = false; playEscaped(); } }
  if (spotter && spotCd <= 0 && free) { spotCd = 30; playSpotted(spotter); }
}
function playSpotted(e) {
  sting('spot'); const ep = e.root.position, dx = player.x - ep.x, dz = player.z - ep.z, d = Math.hypot(dx, dz) || 1, ux = dx / d, uz = dz / d, head = 1.62 * e.root.scale.y; timeScale = .4;
  const reset = () => { camera.fov = 70; camera.updateProjectionMatrix(); };
  cine.play([{ dur: 1.7, cap: 'SPOTTED', big: true, cls: 'spot', cam: k => ({ pos: [ep.x + ux * (3.6 - .9 * k) - uz * .55, head + .05, ep.z + uz * (3.6 - .9 * k) + ux * .55], look: [ep.x, head, ep.z], fov: 42 - 14 * k }), end: reset }], reset);
}
function playEscaped() {
  sting('safe'); const px = driving ? driving.x : player.x, pz = driving ? driving.z : player.z, reset = () => { camera.fov = 70; camera.updateProjectionMatrix(); };
  cine.play([{ dur: 2.4, cap: "LOST THEM · YOU'RE UNSEEN", big: false, cls: 'safe', cam: e => ({ pos: [px + 3 + e * 2, 1.9 + e * 2.6, pz + 4 + e * 4], look: [px, 1.3, pz], fov: 52 }), end: reset }], reset);
}
function endGame() { if (!started) return; paused = true; $('report').textContent = `Hostiles eliminated: ${kills} / ${TOTAL}`; $('end-screen').classList.remove('hidden'); }

// ---------------- vehicles: enter / exit ----------------
function enterVehicle(v) {
  driving = v; mpVehState(1); v.occupied = true; if (op) op.root.visible = false; vm.visible = false; fireHeld = false;
  yaw = v.heading + Math.PI; pitch = -.2; initAudio(); document.body.classList.add('driving'); $('enter').textContent = 'EXIT';
  showMessage(`${v.P.name} — W/S GAS·BRAKE  A/D STEER  SPACE DRIFT`);
}
function exitVehicle() {
  const v = driving; if (!v) return; mpVehState(0); const h = v.heading;
  let x = v.x + Math.cos(h) * v.P.exit, z = v.z - Math.sin(h) * v.P.exit;
  const o = resolveCircle(x, z, .45, world.colliders, 0); x = o.x; z = o.z;
  player.x = x; player.z = z; player.y = EYE; velocityY = 0; grounded = true; v.occupied = false; driving = null;
  if (op) { op.root.visible = camMode === 'tp'; op.root.rotation.y = h; } vm.visible = camMode === 'fp';
  yaw = h + Math.PI; pitch = 0; engineUpdate(0, 0, 0, false); document.body.classList.remove('driving'); $('speedo').textContent = '';
  showMessage('ON FOOT');
}
function toggleVehicle() { if (!started || paused) return; if (driving) exitVehicle(); else if (nearVeh) { if (nearVeh.remote) showMessage('VEHICLE OCCUPIED'); else enterVehicle(nearVeh); } else showMessage('WALK UP TO A VEHICLE'); }
function toggleCam() { if (!op) return; camMode = camMode === 'tp' ? 'fp' : 'tp'; if (!driving) { op.root.visible = camMode === 'tp'; vm.visible = camMode === 'fp'; } showMessage(camMode === 'tp' ? 'THIRD PERSON' : 'FIRST PERSON'); }

// ---------------- game flow ----------------
async function goLandscape() {
  try { if (!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen({ navigationUI: 'hide' }); } catch (e) { }
  try { if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape'); } catch (e) { }
}
const portrait = matchMedia('(orientation: portrait) and (max-width: 900px)');
portrait.addEventListener('change', e => { if (e.matches && started && !paused) pauseGame(); });
function resetGame() {
  decals.forEach(d => d.visible = false); heatActive = false; spotCd = 0; calmT = 0; finaleStarted = false; timeScale = 1; heli.visible = false; cine.onEnd = null; if (cine.active) cine.skip(); document.body.classList.remove('dead'); camera.fov = 70; camera.updateProjectionMatrix();
  if (MOBILE) goLandscape();
  for (const e of enemies) e.dispose(scene); enemies.length = 0;
  if (driving) { driving.occupied = false; driving = null; document.body.classList.remove('driving'); engineUpdate(0, 0, 0, false); }
  vehicles.forEach(v => { v.reset(); v.remote = false; });
  pvx = pvz = 0; player.x = MP ? (net.id - 3) * 2.4 : 0; player.y = EYE; player.z = 60; yaw = 0; pitch = 0; health = 100; ammo = MAG; reserve = 120; kills = 0; velocityY = 0; grounded = true;
  started = true; paused = false; reloading = false; deadAnim = false; if (op) { op.root.rotation.x = 0; } tw = 0; aimW = 0; fireHeld = false;
  if (op) { op.root.visible = camMode === 'tp'; op.root.position.set(player.x, 0, player.z); op.root.rotation.y = Math.PI; }
  vm.visible = camMode === 'fp' || !op; $('enter').textContent = 'ENTER';
  spawnEnemies(); updateHud(); initAudio();
  $('pause-screen').classList.add('hidden'); $('end-screen').classList.add('hidden');
  $('pause-screen').querySelector('h1').textContent = 'TAKE A BREATH.'; $('pause-screen').querySelector('.eyebrow').textContent = 'SIMULATION PAUSED'; $('resume').textContent = 'RESUME MISSION';
  $('hud').style.display = 'block'; $('mobile-controls').style.display = 'block'; $('start-screen').classList.add('hidden'); $('loading').style.display = 'none';
  showMessage('ELIMINATE ALL HOSTILES · VEHICLES NEARBY');
  if (!MP && !introSeen && !Q.get('auto') && !Q.get('nointro')) { introSeen = true; playIntro(); }
}
function pauseGame() { if (!started) return; paused = !MP; $('pause-screen').classList.remove('hidden'); }
function resumeGame() { paused = false; $('pause-screen').classList.add('hidden'); }
$('start').addEventListener('click', resetGame); $('restart').addEventListener('click', resetGame); $('again').addEventListener('click', () => { if (MP) location.href = location.pathname; else resetGame(); });
$('resume').addEventListener('click', () => { if (netLost) { location.href = location.pathname; return; } if (!MP && health <= 0) resetGame(); else resumeGame(); });
$('leave').addEventListener('click', () => { try { net.leave(); } catch (e) { } location.href = location.pathname; });
$('pause').addEventListener('pointerdown', e => { e.preventDefault(); pauseGame(); });
$('fire').addEventListener('pointerdown', e => { e.preventDefault(); fireHeld = true; if (!driving) { shoot(); fireCd = .1; } });
for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) $('fire').addEventListener(ev, () => fireHeld = false);
$('reload').addEventListener('pointerdown', e => { e.preventDefault(); reload(); });
$('jump').addEventListener('pointerdown', e => { e.preventDefault(); if (grounded && started && !paused && !driving) { velocityY = 5.5; grounded = false; } });
$('enter').addEventListener('pointerdown', e => { e.preventDefault(); toggleVehicle(); });
$('skip').addEventListener('pointerdown', e => { e.preventDefault(); cine.skip(); });
$('cam').addEventListener('pointerdown', e => { e.preventDefault(); toggleCam(); });
function setCrouch(v) { crouchOn = v; autoCrouch = false; }
function setZoom(v) { zoomOn = v; }
$('sprint').addEventListener('pointerdown', e => { e.preventDefault(); sprintToggle = !sprintToggle; $('sprint').classList.toggle('on', sprintToggle); });

// look (right side drag)
const look = $('look-zone'); let lookTouch = null;
look.addEventListener('pointerdown', e => { if (!started || paused) return; lookTouch = { id: e.pointerId, x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t0: performance.now(), yaw0: yaw, pitch0: pitch }; look.setPointerCapture(e.pointerId); });
look.addEventListener('pointermove', e => { if (!lookTouch || lookTouch.id !== e.pointerId || paused) return; const dx = e.clientX - lookTouch.x, dy = e.clientY - lookTouch.y; lookTouch.x = e.clientX; lookTouch.y = e.clientY; const zs = 1 - .55 * zoomW; yaw -= dx * .0042 * zs; pitch -= dy * .0035 * zs; pitch = clamp(pitch, -1.25, 1.25); lookT = time; });
// gestures on the look area: quick swipe down = crouch (swipe up = stand), double tap = zoom
let lastTapT = 0, lastTapX = 0, lastTapY = 0;
look.addEventListener('pointerup', e => {
  const lt = lookTouch; lookTouch = null;
  if (!lt || lt.id !== e.pointerId || !started || paused || driving) return;
  const dx = e.clientX - lt.sx, dy = e.clientY - lt.sy, dt = performance.now() - lt.t0;
  if (dt < 350 && dy > 70 && Math.abs(dx) < dy * .7) { yaw = lt.yaw0; pitch = lt.pitch0; setCrouch(true); lastTapT = 0; return; }
  if (dt < 350 && dy < -70 && Math.abs(dx) < -dy * .7 && (crouchOn || autoCrouch)) { yaw = lt.yaw0; pitch = lt.pitch0; setCrouch(false); lastTapT = 0; return; }
  if (dt < 250 && Math.hypot(dx, dy) < 14) {
    const now = performance.now();
    if (now - lastTapT < 320 && Math.hypot(e.clientX - lastTapX, e.clientY - lastTapY) < 50) { setZoom(!zoomOn); lastTapT = 0; }
    else { lastTapT = now; lastTapX = e.clientX; lastTapY = e.clientY; }
  }
});
look.addEventListener('pointercancel', () => lookTouch = null);
// joystick
const joyEl = $('joystick'), stick = $('stick'); let joyId = null;
function joyMove(e) { const r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2; let dx = e.clientX - cx, dy = e.clientY - cy; const max = 39, l = Math.hypot(dx, dy); if (l > max) { dx = dx / l * max; dy = dy / l * max; } joy = { x: dx / max, y: dy / max }; stick.style.left = `calc(50% + ${dx}px)`; stick.style.top = `calc(50% + ${dy}px)`; }
joyEl.addEventListener('pointerdown', e => { e.preventDefault(); joyId = e.pointerId; joyEl.setPointerCapture(e.pointerId); joyMove(e); });
joyEl.addEventListener('pointermove', e => { if (e.pointerId === joyId) joyMove(e); });
function joyEnd() { joyId = null; joy = { x: 0, y: 0 }; stick.style.left = '50%'; stick.style.top = '50%'; }
for (const ev of ['pointerup', 'pointercancel']) joyEl.addEventListener(ev, joyEnd);
// keyboard + mouse
addEventListener('keydown', e => {
  if (e.target && e.target.tagName === 'INPUT') return;
  if (cine.active && (e.code === 'Enter' || e.code === 'Space' || e.code === 'Escape')) { cine.skip(); return; }
  keys[e.code] = true;
  if (e.code === 'Space' && grounded && started && !paused && !driving) { velocityY = 5.5; grounded = false; setCrouch(false); autoCrouch = false; }
  if (e.code === 'KeyC' && !e.repeat) setCrouch(!crouchOn); if (e.code === 'KeyZ' && !e.repeat) setZoom(!zoomOn); if (e.code === 'KeyR') reload(); if (e.code === 'KeyE' && !e.repeat) toggleVehicle(); if (e.code === 'KeyV' && !e.repeat) toggleCam();
  if (e.code === 'Escape' && started) { (MP ? !$('pause-screen').classList.contains('hidden') : paused) ? resumeGame() : pauseGame(); } if (e.code === 'Enter' && !started) resetGame();
});
addEventListener('keyup', e => keys[e.code] = false);
renderer.domElement.addEventListener('click', () => { if (started && !paused && matchMedia('(pointer:fine)').matches) renderer.domElement.requestPointerLock?.(); });
document.addEventListener('mousemove', e => { if (document.pointerLockElement === renderer.domElement) { const zs = 1 - .55 * zoomW; yaw -= e.movementX * .002 * zs; pitch -= e.movementY * .002 * zs; pitch = clamp(pitch, -1.25, 1.25); lookT = time; } });
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('mousedown', e => { if (e.button === 2) zoomHold = true; if (e.button === 0 && started && !paused && matchMedia('(pointer:fine)').matches) { fireHeld = true; if (!driving) { shoot(); fireCd = .1; } } });
document.addEventListener('mouseup', e => { if (e.button === 2) zoomHold = false; if (e.button === 0) fireHeld = false; });

// ---------------- update ----------------
let camDistNow = 3.1;
// ---------- enemies (AI) — in co-op only the host simulates; clients follow its snapshots ----------
function mpTargets() {
  targetPoint(_c); const pt = _c.clone();
  const out = [{ local: true, id: MP ? net.id : 0, alive: !deadAnim, p: { x: player.x, z: player.z, y: player.y + eyeOff, vx: driving ? driving.vx : pvx, vz: driving ? driving.vz : pvz, speed: driving ? driving.speed : Math.hypot(pvx, pvz), inCar: !!driving, sprint: sprintW > .5 }, pt, drv: !!driving, cov: inCover, cr: crouchW }];
  if (MP) for (const r of remotes.values()) if (r.got) out.push({ local: false, id: r.id, alive: !!r.al && r.hp > 0, p: { x: r.x, z: r.z, y: r.ey, vx: r.vx, vz: r.vz, speed: Math.hypot(r.vx, r.vz), inCar: r.dr >= 0, sprint: !!r.sp }, pt: new THREE.Vector3(r.x, r.ch, r.z), drv: r.dr >= 0, cov: !!r.cv, cr: r.cr });
  return out;
}
function pickTarget(T, e) { let best = null, bd = Infinity; const ex = e.root.position.x, ez = e.root.position.z; for (const t of T) { if (!t.alive) continue; const d = (t.p.x - ex) * (t.p.x - ex) + (t.p.z - ez) * (t.p.z - ez); if (d < bd) { bd = d; best = t; } } return best || T[0]; }
function enemiesStep(dt) {
  const puppet = MP && !mpHost;
  director.update(dt);
  const T = mpTargets(), ctx = { player: T[0].p, time, world, vehicles, soldiers: enemies, half: HALF };
  noiseT -= dt; if (noiseT <= 0) { noiseT = .6; if (!puppet) for (const t of T) { if (!t.alive) continue; if (t.p.inCar && t.p.speed > 9) director.makeNoise(t.p.x, t.p.z, 30); else if (t.p.sprint) director.makeNoise(t.p.x, t.p.z, 13); } }
  for (let ei = 0; ei < enemies.length; ei++) {
    const e = enemies[ei], tg = puppet ? T[0] : pickTarget(T, e); ctx.player = tg.p;
    const act = e.update(dt, ctx);
    if (puppet) { puppetSync(e, dt); continue; }
    if (act && act.fire) {
      const pt = tg.pt;
      e.muzzle(_a); const dist = Math.hypot(pt.x - _a.x, pt.z - _a.z); shot(clamp(.14 - dist * .0025, .02, .12), 1500, .07);
      if (act.suppress) { _d.set(act.tx + rand(-3, 3), rand(.3, 1.8), act.tz + rand(-3, 3)); tracer(_a, _d, .018); mpEnemyFire(ei, _a, _d, 1); continue; }
      const sp = Math.tan(act.spread) * dist, ang = Math.random() * 6.283, mag = sp * Math.sqrt(Math.random()), hitR = tg.drv ? 1.5 : (tg.cov ? .3 : tg.cr > .5 ? .38 : .5);
      const ox = Math.cos(ang) * mag, oy = Math.sin(ang) * mag, hit = mag < hitR;
      const dx = pt.x - _a.x, dz = pt.z - _a.z, l = Math.hypot(dx, dz) || 1;
      _d.set(pt.x + (-dz / l) * ox, pt.y + oy, pt.z + (dx / l) * ox); if (!hit && mag < hitR * 2) _d.addScaledVector(_b.set(dx / l, 0, dz / l), 2);
      tracer(_a, _d, .02); mpEnemyFire(ei, _a, _d, 0);
      if (hit) { const dmg = rand(e.T.dmg[0], e.T.dmg[1]) * (tg.drv ? .5 : 1); if (tg.local) damagePlayer(dmg); else net.to(tg.id, { k: 'dm', a: +dmg.toFixed(1) }); }
    }
  }
  if (MP) { for (const e of enemies) if (!e.alive && e.deadT > 5 && e.root.visible) { e.root.visible = false; if (e.icon) e.icon.visible = false; } }
  else for (let i = enemies.length - 1; i >= 0; i--) { const e = enemies[i]; if (!e.alive && e.deadT > 5) { e.dispose(scene); enemies.splice(i, 1); } }
}
function update(dt) {
  if (!started || paused) return;
  if (cine.active) { fireHeld = false; joy = { x: 0, y: 0 }; for (const k in keys) keys[k] = false; }
  if (deadAnim) { time += dt; deadT += dt; const e = Math.min(1, deadT / .9), k = 1 - (1 - e) * (1 - e); if (op) { op.root.rotation.order = 'YXZ'; op.root.rotation.x = -k * 1.45; op.root.position.y = -.05 * k; } { const a = yaw + Math.PI + deadT * .7, r = 3.4 + deadT * .8; camera.position.set(player.x + Math.sin(a) * r, 1.3 + deadT * 1.1, player.z + Math.cos(a) * r); camera.lookAt(player.x, .8, player.z); } if (MP) enemiesStep(dt); updateFx(dt); return; }
  time += dt; fireCd -= dt; kickA = Math.max(0, kickA - dt * 9); flinchA = Math.max(0, flinchA - dt * 4);
  if (health > 0 && health < 100 && time - lastHurt > 5) { health = Math.min(100, health + 7 * dt); updateHud(); }
  nearVeh = driving ? null : nearestVehicle();
  $('enter').classList.toggle('show', !!driving || !!nearVeh); if (nearVeh) $('enter').textContent = 'ENTER ' + nearVeh.P.name;
  if (fireHeld && !driving && fireCd <= 0 && !reloading) { shoot(); fireCd = .105; }
  if (sprintToggle && Math.hypot(pvx, pvz) < .5 && !(Math.hypot(joy.x, joy.y) > .05)) { sprintToggle = false; $('sprint').classList.remove('on'); }

  // ---------- on foot ----------
  let mvx = 0, mvz = 0, spd = 0, wantSprint = false;
  const aimActive = time - lastShot < .9 || (fireHeld && !driving) || ((zoomOn || zoomHold) && !driving);
  if (!driving) {
    const FZ = window.__roles && window.__roles.frozen ? 0 : 1, forward = FZ * ((keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0) - joy.y), side = FZ * ((keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0) + joy.x);
    const len = Math.hypot(forward, side), mag = Math.min(1, len); let dx = 0, dz = 0;
    if (len > .05) { const f = forward / len, s2 = side / len; dx = -Math.sin(yaw) * f + Math.cos(yaw) * s2; dz = -Math.cos(yaw) * f - Math.sin(yaw) * s2; }
    // speed tiers: stick/keys -> walk 2.2 / jog 4.0 / sprint 6.2 (sprint = forward only, not while shooting)
    const joyActive = Math.hypot(joy.x, joy.y) > .05, fwdAmt = len > .05 ? forward / len : 0;
    let target = mag < .01 ? 0 : (joyActive ? (mag < .45 ? 2.2 : 4.0) : (keys.ControlLeft || keys.AltLeft ? 2.2 : 4.0));
    wantSprint = target > 0 && fwdAmt > .3 && !aimActive && (keys.ShiftLeft || keys.ShiftRight || keys.PadShift || sprintToggle || (joyActive && mag > .93));
    if (wantSprint) { target = 6.2; if (crouchOn || autoCrouch) { crouchOn = false; autoCrouch = false; } }
    else if (aimActive) target = Math.min(target, 3.2);
    if (crouchOn || autoCrouch || crouchW > .5) target = Math.min(target, 1.9);
    if (zoomOn || zoomHold) target = Math.min(target, 2.2);
    const tvx = dx * target, tvz = dz * target, acc = grounded ? (target > 0 ? 24 : 34) : 5;
    pvx += clamp(tvx - pvx, -acc * dt, acc * dt); pvz += clamp(tvz - pvz, -acc * dt, acc * dt);
    const ox = player.x, oz = player.z;
    player.x += pvx * dt; player.z += pvz * dt;
    const wasGrounded = grounded;
    velocityY -= 15 * dt; player.y += velocityY * dt; if (player.y <= EYE) { if (!grounded && velocityY < -4) { landDip = Math.min(.12, -velocityY * .012); thud(.07); } player.y = EYE; velocityY = 0; grounded = true; }
    const o = resolveCircle(player.x, player.z, .38, world.colliders, player.y - EYE); player.x = o.x; player.z = o.z;
    for (const v of vehicles) for (const [qx, qz, qr] of v.circles()) { const ddx = player.x - qx, ddz = player.z - qz, d = Math.hypot(ddx, ddz), m = qr + .35; if (d < m && d > 1e-4 && player.y - EYE < .9) { player.x = qx + ddx / d * m; player.z = qz + ddz / d * m; } }
    player.x = clamp(player.x, -LIM, LIM); player.z = clamp(player.z, -LIM, LIM);
    // ---- auto cover: hug tall objects when slow/stopped next to them ----
    { let best = null, bd = inCover ? 1.15 : .9; const px = player.x, pz = player.z;
      for (const c of world.colliders) { if (c.h < .9 || px < c.minX - 1.3 || px > c.maxX + 1.3 || pz < c.minZ - 1.3 || pz > c.maxZ + 1.3) continue; if (c.maxX - c.minX < .8 && c.maxZ - c.minZ < .8) continue;
        const cx2 = clamp(px, c.minX, c.maxX), cz2 = clamp(pz, c.minZ, c.maxZ), d = Math.hypot(px - cx2, pz - cz2); if (d < bd) { bd = d; best = { c, nx: (px - cx2) / (d || 1), nz: (pz - cz2) / (d || 1) }; } }
      const slow = Math.hypot(pvx, pvz) < 1.6 && !wantSprint && grounded;
      if (best && slow) { inCover = true; coverN = best; coverLow = best.c.h < 1.7; if (coverLow && !crouchOn) autoCrouch = true; }
      else if (inCover && (!best || Math.hypot(pvx, pvz) > 2.6 || wantSprint)) { inCover = false; coverN = null; autoCrouch = false; }
      $('covertag').classList.toggle('on', inCover); }
    // actual displacement (so animation stops when you push into a wall)
    const adx = (player.x - ox) / Math.max(dt, 1e-3), adz = (player.z - oz) / Math.max(dt, 1e-3);
    if (Math.hypot(adx, adz) < Math.hypot(pvx, pvz) * .5) { pvx = adx; pvz = adz; }
    mvx = pvx; mvz = pvz; spd = Math.hypot(pvx, pvz);
  }
  // ---------- vehicles ----------
  const others = vehicles;
  for (const v of vehicles) {
    if (v.wreck) continue;
    if (v.remote && v !== driving) { if (v.rs) v.applyRemote(v.rs, dt); continue; }
    if (v === driving) {
      const thr = clamp((keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0) - joy.y, -1, 1), st = clamp((keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0) + joy.x, -1, 1);
      v.update(dt, { thr: padTrig !== 0 ? clamp(padTrig, -1, 1) : thr, st, hb: !!keys.Space || fireHeld || padHB }, world.colliders, others, fx);
      if (v.impact > 2.5) { thud(clamp(v.impact * .05, .1, .45)); camShake = Math.min(1, v.impact * .08); for (let i = 0; i < 8; i++) parts.spawn({ p: new THREE.Vector3(v.x, .5, v.z), v: [rand(-5, 5), rand(1, 5), rand(-5, 5)], life: rand(.3, .6), s0: .1, s1: .03, color: 0xffc060, add: true, grav: 12, drag: .3 }); }
      engineUpdate(thr, Math.abs(v.vl), v.skidAmt + (thr > .9 && v.vl < 5 && v.vl > -1 ? 6 : 0) + ((keys.Space || fireHeld) && Math.abs(v.vl) > 4 ? 6 : 0), true);
      // run enemies over
      if (v.speed > 5.5) for (const e of enemies) if (e.alive) for (const [qx, qz, qr] of v.circles()) if (Math.hypot(e.root.position.x - qx, e.root.position.z - qz) < qr + .4) {
        if (MP && !mpHost) { if ((e._rk || 0) < time) { e._rk = time + .6; net.host_({ k: 'eh', i: enemies.indexOf(e), d: 9999, h: 0, rk: 1 }); } continue; } e.hit(9999, false, null); kills++; reserve += 15; updateHud(); showMessage('ROADKILL'); hitMarker(true); thud(.4); puff(_a.set(e.root.position.x, .8, e.root.position.z), 1.2, true);
        checkWin(); break;
      }
      player.x = v.x; player.z = v.z;
      $('speedo').innerHTML = `${Math.round(v.speed * 3.6)}<small> km/h</small>`;
    } else if (v.speed > .05 || Math.abs(v.vl) > .05) v.update(dt, { thr: 0, st: 0, hb: true }, world.colliders, others, fx);
  }
  enemiesStep(dt);

  // ---------- operator model ----------
  aimW += ((aimActive ? 1 : 0) - aimW) * Math.min(1, 10 * dt);
  crouchW += (((crouchOn || autoCrouch) && !driving ? 1 : 0) - crouchW) * Math.min(1, 9 * dt); zoomW += (((zoomOn || zoomHold) && !driving ? 1 : 0) - zoomW) * Math.min(1, 10 * dt); eyeOff = -(EYE - 1.12) * crouchW; coverUp += ((inCover && coverLow ? .6 : 0) - coverUp) * Math.min(1, 6 * dt);
  if (op && !driving) {
    const eyeFeet = player.y - EYE - landDip; op.root.position.set(player.x, eyeFeet, player.z);
    const moving = spd > .3, ry = op.root.rotation.y;
    let fa = null; if (aimActive) fa = yaw + Math.PI; else if (inCover && coverN && spd < .6) fa = coverLow ? Math.atan2(-coverN.nx, -coverN.nz) : Math.atan2(coverN.nx, coverN.nz); else if (moving) fa = Math.atan2(mvx, mvz);
    if (fa !== null) op.root.rotation.y += wrapPi(fa - ry) * Math.min(1, (aimActive ? 18 : 12) * dt);
    let sgn = 1, rel = 0;
    if (moving) { rel = wrapPi(Math.atan2(mvx, mvz) - op.root.rotation.y); if (Math.abs(rel) > Math.PI / 2) { sgn = -1; rel -= Math.sign(rel) * Math.PI; } }
    const prevTw = tw; if (moving && grounded) tw += sgn * spd * dt / stride(spd);
    sw += ((moving ? 1 : 0) - sw) * Math.min(1, 10 * dt);
    runW += ((spd > 2.6 ? 1 : 0) - runW) * Math.min(1, 8 * dt); sprintW += ((wantSprint && spd > 4.5 ? 1 : 0) - sprintW) * Math.min(1, 6 * dt);
    airW += ((grounded ? 0 : 1) - airW) * Math.min(1, 14 * dt); landDip *= Math.max(0, 1 - 9 * dt);
    relS += wrapPi(rel - relS) * Math.min(1, 12 * dt); if (moving) lastSpd = Math.max(spd, .4);
    if (grounded && moving && Math.floor(tw * 2) !== Math.floor(prevTw * 2)) { footstep(sprintW > .5 ? .06 : .035); if (sprintW > .5) puff(_a.set(player.x, .12, player.z), .5); }
    try { op.pose(tw, sw, time, lastSpd, aimW, pitch + recoil, op.rifle, { run: runW, rel: relS, air: airW, sprint: sprintW, crouch: crouchW, reload: reloading ? (time - reloadStart) / 1.15 : -1, kick: kickA, flinch: flinchA }); } catch (e) { console.error(e); op = null; }
  }
  if (op && op.root.visible === false) { /* keep pose time moving */ }
  vm.position.z += (-.45 - vm.position.z) * Math.min(1, 14 * dt);
  vm.position.y = -.17 + Math.sin(time * 9) * .006 * Math.min(1, spd);
  updateAwareness(dt);
  if (!cine.active) updateCamera(dt);
  updateFx(dt);
  radarT -= dt; if (radarT <= 0) { radarT = .07; drawRadar(); }
  // sun follows the action so shadows stay sharp
  sun.position.set(player.x + 34, 22, player.z + 16); sun.target.position.set(player.x, 0, player.z);
  $('crosshair').style.display = driving ? 'none' : 'block';
}
function updateCamera(dt) {
  camShake = Math.max(0, camShake - dt * 3);
  if (driving) {
    const v = driving, fovT = 62 + Math.min(v.speed, 34) * .5; camera.fov += (fovT - camera.fov) * Math.min(1, 4 * dt); camera.updateProjectionMatrix();
    if (time - lookT > 1.6 && v.speed > 1.5) { const tgt = (v.vl >= -.5 ? v.heading : v.heading + Math.PI) + Math.PI; yaw += wrapPi(tgt - yaw) * Math.min(1, 1.6 * dt); pitch += (-.2 - pitch) * Math.min(1, 1.2 * dt); }
  } else { const ft = (70 + 9 * sprintW) * (1 - .45 * zoomW); if (Math.abs(camera.fov - ft) > .05) { camera.fov += (ft - camera.fov) * Math.min(1, 6 * dt); camera.updateProjectionMatrix(); } }
  const pv = pitch + recoil; recoil *= Math.max(0, 1 - 7 * dt);
  const cp = Math.cos(pv), fx_ = -Math.sin(yaw) * cp, fy_ = Math.sin(pv), fz_ = -Math.cos(yaw) * cp;
  if (driving || (op && camMode === 'tp')) {
    const dist = driving ? 7.6 : 3.1 - 1.15 * zoomW, up = driving ? 1.5 : player.y - EYE + 1.5 + eyeOff * .9 + coverUp;
    const px = driving ? driving.x : player.x, pz = driving ? driving.z : player.z, rx = Math.cos(yaw), rz = -Math.sin(yaw);
    let side = driving ? 0 : .6 + .15 * aimW + .2 * zoomW;
    if (side > 0) { const sh = firstWallHit(px, up, pz, rx, 0, rz, world.colliders, side + .3); if (sh < side + .3) side = Math.max(0, sh - .25); }
    const ox = px + rx * side, oz = pz + rz * side;
    let tx = -fx_, ty = -fy_, tz = -fz_, d = dist;
    const hitD = firstWallHit(ox, up, oz, tx, ty, tz, world.colliders, dist + .3); if (hitD < dist + .3) d = Math.max(.6, hitD - .3);
    for (const v of vehicles) { if (v === driving) continue; for (const [qx, qz, qr] of v.circles()) { const t = raySphere(ox, up, oz, tx, ty, tz, qx, .9, qz, qr * 1.1); if (t < d) d = Math.max(.6, t - .15); } }
    let cy = up + ty * d; if (cy < .3) { d = Math.max(.5, d * (up - .3) / (up - cy)); cy = up + ty * d; }
    camDistNow = d; camera.position.set(ox + tx * d, cy, oz + tz * d);
    camera.rotation.set(pv, yaw, 0, 'YXZ');
    if (op) op.root.visible = !driving && camMode === 'tp' && d > .9;
  } else {
    camDistNow = 0; camera.position.set(player.x, player.y + eyeOff + Math.sin(time * 9) * .022 * Math.min(1, Math.hypot(pvx, pvz) / 4), player.z); camera.rotation.set(pv + Math.sin(time * 1.3) * .0015, yaw, Math.sin(time * 1.1) * .002, 'YXZ');
    if (op) op.root.visible = false;
  }
  if (camShake > 0) { camera.position.x += (Math.random() - .5) * camShake * .15; camera.position.y += (Math.random() - .5) * camShake * .15; }
  if (window.__roles) window.__roles.cam(camera, dt);
}
const radar = $('radar'), rctx = radar ? radar.getContext('2d') : null;
function drawRadar() {
  if (!rctx) return; const S = radar.width, c = S / 2, R = 62, k = c / R; rctx.clearRect(0, 0, S, S);
  rctx.save(); rctx.beginPath(); rctx.arc(c, c, c - 1, 0, 7); rctx.clip(); rctx.fillStyle = 'rgba(12,20,26,.62)'; rctx.fillRect(0, 0, S, S);
  const cy = Math.cos(yaw), sy = Math.sin(yaw), fx = -sy, fz = -cy, rx = cy, rz = -sy;
  const P = (x, z) => { const dx = x - player.x, dz = z - player.z; return [c + (dx * rx + dz * rz) * k, c - (dx * fx + dz * fz) * k]; };
  // arena bounds
  rctx.strokeStyle = 'rgba(120,170,200,.5)'; rctx.lineWidth = 1.5; rctx.beginPath(); [[-HALF, -HALF], [HALF, -HALF], [HALF, HALF], [-HALF, HALF]].forEach(([x, z], i) => { const [a, b] = P(x, z); i ? rctx.lineTo(a, b) : rctx.moveTo(a, b); }); rctx.closePath(); rctx.stroke();
  for (const e of enemies) { if (!e.alive || e.alert || Math.hypot(e.root.position.x - player.x, e.root.position.z - player.z) > 62) continue; const ry = e.root.rotation.y; rctx.fillStyle = 'rgba(255,200,60,.16)'; rctx.beginPath(); const [a0, b0] = P(e.root.position.x, e.root.position.z); rctx.moveTo(a0, b0); for (let s = -4; s <= 4; s++) { const an = ry + s * .28, [a, b] = P(e.root.position.x + Math.sin(an) * 30, e.root.position.z + Math.cos(an) * 30); rctx.lineTo(a, b); } rctx.closePath(); rctx.fill(); }
  // main roads
  rctx.strokeStyle = 'rgba(160,170,180,.35)'; rctx.lineWidth = 2.5; for (const [x0, z0, x1, z1] of [[0, -60, 0, 68], [-68, 0, 68, 0], [-40, -60, -40, 52], [40, -60, 40, 52], [-40, -45, 40, -45]]) { const [a, b] = P(x0, z0), [d, e] = P(x1, z1); rctx.beginPath(); rctx.moveTo(a, b); rctx.lineTo(d, e); rctx.stroke(); }
  for (const v of vehicles) { if (v.wreck || v === driving) continue; const [a, b] = P(v.x, v.z); rctx.fillStyle = '#58a6ff'; rctx.fillRect(a - 2, b - 2, 4, 4); }
  for (const e of enemies) { if (!e.alive) continue; const d = Math.hypot(e.root.position.x - player.x, e.root.position.z - player.z), [a, b] = P(e.root.position.x, e.root.position.z); if (e.alert) { rctx.fillStyle = '#ff4a3a'; rctx.beginPath(); rctx.arc(a, b, 3.2, 0, 7); rctx.fill(); } else if (d < 26) { rctx.strokeStyle = '#f0a52b'; rctx.lineWidth = 1.4; rctx.beginPath(); rctx.arc(a, b, 2.6, 0, 7); rctx.stroke(); } }
  if (MP) for (const r of remotes.values()) { if (!r.got) continue; const [a, b] = P(r.x, r.z); rctx.fillStyle = '#4ad0ff'; rctx.fillRect(a - 2.5, b - 2.5, 5, 5); }
  rctx.restore(); rctx.fillStyle = '#fff'; rctx.beginPath(); rctx.moveTo(c, c - 6); rctx.lineTo(c - 4.5, c + 5); rctx.lineTo(c + 4.5, c + 5); rctx.closePath(); rctx.fill();
  rctx.strokeStyle = 'rgba(255,255,255,.45)'; rctx.lineWidth = 1.5; rctx.beginPath(); rctx.arc(c, c, c - 1, 0, 7); rctx.stroke();
}

// ================= Gamepad (PS4 DualShock 4 / DualSense / Xbox via Bluetooth, standard mapping) =================
let padPrev = [], padOn = false, padF = false, padZ = false, padTrig = 0, padHB = false, padStick = false;
const dz = (v = 0, d = .17) => Math.abs(v) < d ? 0 : Math.sign(v) * (Math.abs(v) - d) / (1 - d);
const getPad = () => { const l = navigator.getGamepads ? navigator.getGamepads() : []; for (const g of l) if (g && g.connected) return g; return null; };
function rumble(s = .3, w = .2, ms = 80) { try { const g = getPad(); if (g && g.vibrationActuator) g.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: s, weakMagnitude: w }); } catch (e) { } }
function pollPad(dt) {
  const g = getPad();
  if (!g) { if (padOn) { padOn = false; document.body.classList.remove('padmode'); if (padStick) { joy = { x: 0, y: 0 }; padStick = false; } keys.PadShift = false; padTrig = 0; padHB = false; } return; }
  if (!padOn) { padOn = true; document.body.classList.add('padmode'); showMessage('CONTROLLER: R2 FIRE · L2 ZOOM · ✕ JUMP · ○ CROUCH · □ RELOAD · △ CAR'); }
  const std = g.mapping === 'standard', B = i => !!(g.buttons[i] && g.buttons[i].pressed), V = i => g.buttons[i] ? g.buttons[i].value : 0, hit = i => B(i) && !padPrev[i];
  const lx = dz(g.axes[0]), ly = dz(g.axes[1]), rx = dz(g.axes[2]), ry = dz(std ? g.axes[3] : g.axes[5]);
  const r2 = std ? V(7) : Math.max(0, ((g.axes[4] ?? -1) + 1) / 2), l2 = std ? V(6) : Math.max(0, ((g.axes[3] ?? -1) + 1) / 2);
  const finish = () => { padPrev = g.buttons.map(b => b.pressed); };
  if (cine.active) { if (hit(0) || hit(1) || hit(9)) cine.skip(); finish(); return; }
  if (!started) { if (hit(0) || hit(9)) resetGame(); finish(); return; }
  if (paused) { if (hit(0) || hit(9)) { if (health <= 0 || !$('end-screen').classList.contains('hidden')) resetGame(); else resumeGame(); } finish(); return; }
  if (joyId === null) { const m = Math.hypot(lx, ly); if (m > 0) { const tm = (keys.PadShift || sprintToggle) ? Math.min(1, m) : Math.min(m, .9); joy = { x: lx / m * tm, y: ly / m * tm }; padStick = true; } else if (padStick) { joy = { x: 0, y: 0 }; padStick = false; } }
  if (rx || ry) { const zs = 1 - .55 * zoomW; yaw -= rx * dt * 3.4 * zs; pitch = clamp(pitch - ry * dt * 2.4 * zs, -1.25, 1.25); lookT = time; }
  keys.PadShift = B(5);
  if (hit(10)) { sprintToggle = !sprintToggle; $('sprint').classList.toggle('on', sprintToggle); }
  if (driving) {
    padTrig = (r2 - l2); if (Math.abs(padTrig) < .05) padTrig = 0; padHB = B(1) || B(0);
    if (padF) { fireHeld = false; padF = false; } if (padZ) { zoomHold = false; padZ = false; }
  } else {
    padTrig = 0; padHB = false;
    if (r2 > .35) { fireHeld = true; padF = true; } else if (padF) { fireHeld = false; padF = false; }
    if (l2 > .35) { zoomHold = true; padZ = true; } else if (padZ) { zoomHold = false; padZ = false; }
    if (hit(0) && grounded) { velocityY = 5.5; grounded = false; setCrouch(false); autoCrouch = false; }
    if (hit(1)) setCrouch(!crouchOn);
    if (hit(2)) reload();
  }
  if (hit(3)) toggleVehicle(); if (hit(4)) toggleCam(); if (hit(9)) pauseGame();
  finish();
}
// ---- adaptive quality: starts high, steps down if the device can't hold ~30 fps ----
let quality = Q.get('q') ? +Q.get('q') : 2, frameN = 0, accT = 0, accN = 0, qHold = 3;
function setQuality(q) {   // 0 low · 1 medium · 2 high · 3 ultra
  quality = q; renderer.setPixelRatio(q >= 3 ? Math.min(2, devicePixelRatio) : q === 2 ? PR() : q === 1 ? Math.min(1.1, PR()) : .85); renderer.setSize(innerWidth, innerHeight);
  sun.castShadow = q > 0; scene.fog.far = q === 0 ? 140 : q >= 3 ? 230 : 190;
  const ms = q >= 3 ? (MOBILE ? 2048 : 4096) : (MOBILE ? 1024 : 2048);
  if (sun.shadow.mapSize.x !== ms) { sun.shadow.mapSize.set(ms, ms); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
  const sr = q >= 3 ? 34 : 26; sc.left = sc.bottom = -sr; sc.right = sc.top = sr; sc.updateProjectionMatrix();
  renderer.shadowMap.needsUpdate = true; if (window.__gfx) window.__gfx.apply(q);
}
function animate() {
  requestAnimationFrame(animate); const raw = clock.getDelta(), dt = Math.min(raw, .035); pollPad(dt); const dts = dt * timeScale; timeScale = Math.min(1, timeScale + raw * .9); update(dts); mpFrame(dts); if (window.__roles) window.__roles.frame(raw); netTick(raw); if (cine.active) cine.update(raw);
  if (heli.visible) { heli.userData.rotor.rotation.y += 38 * raw; heli.userData.tail.rotation.z += 50 * raw; heliBeat -= raw; if (heliBeat <= 0) { heliBeat = .13; shot(.05, 170, .09); } }
  if (quality > 0 && (quality < 2 || MOBILE ? (frameN & 1) === 0 : true)) renderer.shadowMap.needsUpdate = true;
  frameN++; renderer.render(scene, camera);
  if (started && !paused) { accT += raw; accN++; if (accT > 2.5) { const avg = accT / accN; accT = 0; accN = 0; if (qHold > 0) qHold--; else if (avg > .042 && quality > 0 && !Q.get('q') && !window.__gfxLock) { setQuality(quality - 1); qHold = 1; } } }
}
addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); setQuality(quality); });

// ---------------- multiplayer: co-op, up to 5 players ----------------
// Model: every player simulates themselves; the HOST also simulates the enemy AI and broadcasts snapshots.
// Clients show enemies as puppets, send "enemy hit" events to the host, and receive damage/kill events back.
const net = new Net(), remotes = new Map(), STATES = ['patrol', 'invest', 'search', 'combat', 'retreat', 'evade'];
let netT = 0, snapT = 0, hudT = 0, vehT = 0, mpName = 'Operator';
const r2 = n => Math.round(n * 100) / 100;
function stubBrain() { return { state: 'patrol', awareness: 0, sees: false, sub: '', pAct: { vx: 0, vz: 0, face: null, fire: false }, update() { const p = this.pAct, o = { vx: p.vx, vz: p.vz, face: p.face, fire: p.fire }; p.fire = false; return o; }, hear() { }, onHit() { }, releaseCover() { }, spot() { } }; }
function hitEnemy(e, dmg, head, from) {
  if (MP && !mpHost) { const i = enemies.indexOf(e); if (i >= 0) net.host_({ k: 'eh', i, d: dmg, h: head ? 1 : 0 }); e.hitT = .12; e.kick = .6; return false; }
  return e.hit(dmg, head, from || player);
}
function creditKill(by, msg) {
  if (!MP || !by || by === net.id) { kills++; reserve += 15; health = Math.min(100, health + 5); updateHud(); showMessage(msg); }
  else net.to(by, { k: 'kill', m: msg });
  checkWin();
}
function puppetSync(e, dt) {      // clients: follow the host's enemy positions (extrapolated by velocity so there is no lag-pull)
  const t = e._tgt; if (!t || !e.alive) return;
  t.x += t.vx * dt; t.z += t.vz * dt;
  const dx = t.x - e.root.position.x, dz = t.z - e.root.position.z, d = Math.hypot(dx, dz);
  if (d > 4) { e.root.position.x = t.x; e.root.position.z = t.z; } else { const k = Math.min(1, 7 * dt); e.root.position.x += dx * k; e.root.position.z += dz * k; }
}
function mpEnemyFire(i, a, b, sup) { if (MP && mpHost) net.all({ k: 'ef', i, a: [r2(a.x), r2(a.y), r2(a.z)], b: [r2(b.x), r2(b.y), r2(b.z)], s: sup }); }
function mpShot(a, b) { if (MP) net.all({ k: 'sh', a: [r2(a.x), r2(a.y), r2(a.z)], b: [r2(b.x), r2(b.y), r2(b.z)] }); }
function mpBarrel(b) { if (MP) net.all({ k: 'ba', i: world.barrels.indexOf(b) }); }
function mpVehState(on) {
  if (!MP || !driving) return; const v = driving;
  net.all({ k: 'veh', i: vehicles.indexOf(v), on, x: r2(v.x), z: r2(v.z), h: +v.heading.toFixed(3), vx: r2(v.vx), vz: r2(v.vz), vl: r2(v.vl), st: +v.steer.toFixed(3) });
}
function respawnLocal() {
  if (!MP || !deadAnim) return;
  if (driving) exitVehicle();
  document.body.classList.remove('dead'); deadAnim = false; health = 100; ammo = MAG; reloading = false; lastHurt = time;
  pvx = pvz = 0; velocityY = 0; grounded = true; fireHeld = false; player.x = (net.id - 3) * 2.4; player.z = 60; player.y = EYE; yaw = 0; pitch = 0;
  if (op) { op.root.rotation.x = 0; op.root.position.y = 0; } updateHud(); showMessage('BACK IN THE FIGHT');
}
// ---- remote players ----
function makeTag(name) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
  x.fillStyle = 'rgba(10,14,20,.72)'; x.fillRect(0, 8, 256, 48); x.strokeStyle = '#4ad0ff'; x.lineWidth = 3; x.strokeRect(1.5, 9.5, 253, 45);
  x.fillStyle = '#fff'; x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(name, 128, 33);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false, depthWrite: false }));
  s.scale.set(1.3, .325, 1); s.position.y = 2.45; s.renderOrder = 21; return s;
}
function addRemote(id, name) {
  if (remotes.has(id) || id === net.id) return;
  const sol = new Soldier('rifleman', scene, 0, 60, { squad: -2, dir: director }); sol.brain = stubBrain(); sol.root.visible = false; sol.root.add(makeTag(name));
  remotes.set(id, { id, name, sol, x: 0, z: 60, ch: 1.1, ey: 1.72, ry: 0, vx: 0, vz: 0, cr: 0, cv: 0, dr: -1, hp: 100, al: 1, sp: 0, got: false });
}
function dropRemote(id) {
  const r = remotes.get(id); if (!r) return; r.sol.dispose(scene); remotes.delete(id);
  for (const v of vehicles) if (v.rid === id) { v.remote = false; v.occupied = false; v.rid = 0; }
}
function reviveVisual(s) { s.root.position.y = 0; s.pelvis.rotation.set(0, 0, 0); if (s.ext) { s.ext.holder.rotation.x = 0; s.ext.holder.position.y = 0; for (const q of [s.ext.hi, s.ext.lo]) if (q) q.mixer.timeScale = 1; } }
const rctx2 = { player: { x: 0, z: 0, y: 1.7, vx: 0, vz: 0, speed: 0, inCar: false, sprint: false }, time: 0, world, vehicles, soldiers: enemies, half: HALF };
function mpFrame(dt) {
  if (!MP || !started) return;
  rctx2.time = time; rctx2.player.x = player.x; rctx2.player.z = player.z;
  for (const r of remotes.values()) {
    const s = r.sol; if (!r.got) { s.root.visible = false; continue; }
    const inCar = r.dr >= 0; s.root.visible = !inCar;
    const alive = !!r.al && r.hp > 0; if (s.alive !== alive) { s.alive = alive; s.deadT = 0; s.flash.visible = false; if (alive) reviveVisual(s); }
    r.x += r.vx * dt; r.z += r.vz * dt;
    const a = s.brain.pAct; a.vx = r.vx; a.vz = r.vz; a.face = r.ry;
    s.update(dt, rctx2);
    if (inCar) { const v = vehicles[r.dr]; if (v) { r.x = v.x; r.z = v.z; } s.root.position.x = r.x; s.root.position.z = r.z; continue; }
    const dx = r.x - s.root.position.x, dz = r.z - s.root.position.z, d = Math.hypot(dx, dz);
    if (d > 4) { s.root.position.x = r.x; s.root.position.z = r.z; } else { const k = Math.min(1, 8 * dt); s.root.position.x += dx * k; s.root.position.z += dz * k; }
    s.root.scale.y = s.T.scale * (1 - .2 * r.cr);
  }
}
function mpSendState() {
  net.all({ k: 'p', x: r2(player.x), z: r2(player.z), ch: r2(driving ? 1.1 : player.y - .45 + eyeOff * .8), ey: r2(player.y + eyeOff), ry: r2(op ? op.root.rotation.y : yaw + Math.PI), vx: r2(driving ? driving.vx : pvx), vz: r2(driving ? driving.vz : pvz), cr: r2(crouchW), cv: inCover ? 1 : 0, dr: driving ? vehicles.indexOf(driving) : -1, hp: Math.round(health), al: deadAnim ? 0 : 1, sp: sprintW > .5 ? 1 : 0 });
}
function netTick(dt) {
  if (!MP || !started) return;
  netT -= dt; if (netT <= 0) { netT = 1 / 15; mpSendState(); if (driving) mpVehState(1); }
  if (mpHost) { snapT -= dt; if (snapT <= 0) { snapT = 1 / 12; net.all({ k: 'es', e: enemies.map(e => [r2(e.root.position.x), r2(e.root.position.z), r2(e.vx), r2(e.vz), r2(e.root.rotation.y), e.alive ? 1 : 0, Math.max(0, STATES.indexOf(e.brain.state)), r2(e.brain.awareness || 0), e.brain.sees ? 1 : 0]) }); } }
  hudT -= dt; if (hudT <= 0) { hudT = .5; updateHud(); }
}
function becomeHost() {
  mpHost = true; for (const e of enemies) if (e.alive && e.brain.pAct) e.brain = new Brain(e, director, e._patrol);
  showMessage('HOST LEFT — YOU ARE NOW HOST'); updateMpInfo();
}
function onMsg(from, d) {
  if (window.__roles && window.__roles.onMsg(from, d)) return;
  const r = remotes.get(from);
  switch (d.k) {
    case 'p': if (!r) break; { const first = !r.got; r.x = d.x; r.z = d.z; r.ch = d.ch; r.ey = d.ey; r.ry = d.ry; r.vx = d.vx; r.vz = d.vz; r.cr = d.cr; r.cv = d.cv; r.dr = d.dr; r.hp = d.hp; r.al = d.al; r.sp = d.sp; if (first) { r.got = true; r.sol.root.position.set(d.x, 0, d.z); r.sol.alive = !!d.al; } } break;
    case 'sh': if (!r) break; _a.set(d.a[0], d.a[1], d.a[2]); _d.set(d.b[0], d.b[1], d.b[2]); tracer(_a, _d, .025); shot(clamp(.14 - Math.hypot(player.x - d.a[0], player.z - d.a[2]) * .0025, .02, .12), 2000, .07);
      r.sol.flash.visible = true; r.sol.flashT = .05; if (r.sol.ext) r.sol.ext.kick(); if (mpHost) director.makeNoise(r.x, r.z, 58); break;
    case 'es': if (mpHost || !started) break; for (let i = 0; i < d.e.length && i < enemies.length; i++) {
        const s = d.e[i], e = enemies[i]; if (!e) continue; e._tgt = { x: s[0], z: s[1], vx: s[2], vz: s[3] }; const a = e.brain.pAct; a.vx = s[2]; a.vz = s[3]; a.face = s[4];
        e.brain.state = STATES[s[6]] || 'patrol'; e.brain.awareness = s[7]; e.brain.sees = !!s[8];
        if (!s[5] && e.alive) { e.alive = false; e.deadT = e._seen ? 0 : 10; e.flash.visible = false; if (e._seen) { e.hitT = .12; } } e._seen = true;
      } break;
    case 'ef': { const e = enemies[d.i]; if (!e || mpHost) break; e.brain.pAct.fire = true; _a.set(d.a[0], d.a[1], d.a[2]); _d.set(d.b[0], d.b[1], d.b[2]); tracer(_a, _d, d.s ? .018 : .02); shot(clamp(.14 - Math.hypot(player.x - d.a[0], player.z - d.a[2]) * .0025, .02, .12), 1500, .07); } break;
    case 'eh': { if (!mpHost) break; const e = enemies[d.i]; if (!e || !e.alive) break; const dead = e.hit(d.d, !!d.h, r ? { x: r.x, z: r.z } : null); if (dead) { net.to(from, { k: 'kill', m: d.rk ? 'ROADKILL' : d.h ? 'HEADSHOT' : 'HOSTILE ELIMINATED', h: d.h }); checkWin(); } } break;
    case 'kill': kills++; reserve += 15; health = Math.min(100, health + 5); updateHud(); showMessage(d.m || 'HOSTILE ELIMINATED'); hitMarker(true); break;
    case 'dm': damagePlayer(d.a); break;
    case 'ba': { const b = world.barrels[d.i]; if (b && b.alive) explode(b, from); } break;
    case 'win': if (!finaleStarted) { finaleStarted = true; timeScale = .25; setTimeout(playOutro, 1100); } break;
    case 'veh': { const v = vehicles[d.i]; if (!v || v === driving) break;
      if (d.on) { v.remote = true; v.occupied = true; v.rid = from; v.rs = { x: d.x, z: d.z, h: d.h, vx: d.vx, vz: d.vz, vl: d.vl, st: d.st, t: performance.now() }; }
      else { v.remote = false; v.occupied = false; v.rid = 0; v.group.position.x = d.x; v.group.position.z = d.z; v.group.rotation.y = d.h; v.vx = d.vx; v.vz = d.vz; } } break;
  }
}
// ---- lobby UI ----
function mpErr(t) { $('mp-err').textContent = t || ''; }
function updateMpInfo() { const el = $('mpinfo'); if (!el) return; el.textContent = MP ? `ROOM ${net.room} · ${net.players.length}/5${mpHost ? ' · HOST' : ''}` : ''; }
function renderLobby() {
  $('mp-room').textContent = net.room; $('mp-list').innerHTML = '';
  for (const p of net.players) { const li = document.createElement('li'); li.textContent = p.name + (p.id === net.host ? '  ★ HOST' : '') + (p.id === net.id ? '  (YOU)' : ''); $('mp-list').appendChild(li); }
  $('mp-count').textContent = `${net.players.length} / 5 PLAYERS`;
  $('mp-start').classList.toggle('hidden', !net.isHost); $('mp-wait').classList.toggle('hidden', net.isHost);
}
function startMP() {
  if (MP) return; MP = true; mpHost = net.isHost; document.body.classList.add('mp'); introSeen = true;
  for (const p of net.players) addRemote(p.id, p.name);
  $('mp-screen').classList.add('hidden'); resetGame(); updateMpInfo();
}
async function mpConnect(mode) {
  mpName = ($('mp-name').value.trim() || (mode === 'lan' ? (MOBILE ? 'Phone' : 'PC') + (100 + Math.floor(Math.random() * 900)) : 'Operator')).slice(0, 12); let url = $('mp-server').value.trim();
  if (!url) { mpErr('Enter the server address'); return; }
  if (!/^wss?:\/\//i.test(url)) { const lan = /^(https?:\/\/)?(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|[^\/:]+\.local)/i.test(url); url = (!lan && location.protocol === 'https:' ? 'wss://' : 'ws://') + url.replace(/^https?:\/\//i, ''); }
  if (!/\/mp$/.test(url)) url = url.replace(/\/+$/, '') + '/mp';
  if (mode === 'join' && !$('mp-code').value.trim()) { mpErr('Enter the 4-letter room code'); return; }
  try { localStorage.setItem('sp_name', mpName); localStorage.setItem('sp_server', $('mp-server').value.trim()); } catch (e) { }
  mpErr('Connecting…'); $('mp-create').disabled = $('mp-join').disabled = true;
  try { await net.connect(url); } catch (e) { mpErr(e.message + ' — check the address'); $('mp-create').disabled = $('mp-join').disabled = false; return; }
  mpErr(''); if (mode === 'create') net.create(mpName); else if (mode === 'lan') net.lan(mpName); else net.join($('mp-code').value.trim(), mpName);
}
net.on('joined', m => { $('mp-form').classList.add('hidden'); $('mp-lobby').classList.remove('hidden'); renderLobby(); if (net.started) startMP(); });
net.on('err', m => { mpErr(m.msg); $('mp-create').disabled = $('mp-join').disabled = false; try { net.ws.onclose = null; net.ws.close(); } catch (e) { } net.open = false; });
net.on('roster', m => {
  const wasHost = mpHost; renderLobby();
  if (MP) {
    for (const p of net.players) addRemote(p.id, p.name);
    for (const id of [...remotes.keys()]) if (!net.players.some(p => p.id === id)) dropRemote(id);
    if (net.isHost && !wasHost) becomeHost(); else updateMpInfo();
  }
});
net.on('start', () => startMP());
net.on('msg', m => { if (MP) onMsg(m.from, m.d); });
net.on('close', () => { if (!MP) { mpErr('Disconnected from server'); return; } netLost = true; paused = true; $('pause-screen').classList.remove('hidden'); $('pause-screen').querySelector('h1').textContent = 'CONNECTION LOST'; $('pause-screen').querySelector('.eyebrow').textContent = 'MULTIPLAYER'; $('resume').textContent = 'BACK TO MENU'; });
$('mp-open').addEventListener('click', () => { $('start-screen').classList.add('hidden'); $('mp-screen').classList.remove('hidden'); });
$('mp-back').addEventListener('click', () => { if (net.open) { try { net.leave(); net.ws.onclose = null; net.ws.close(); } catch (e) { } net.open = false; net.id = 0; $('mp-lobby').classList.add('hidden'); $('mp-form').classList.remove('hidden'); $('mp-create').disabled = $('mp-join').disabled = false; } $('mp-screen').classList.add('hidden'); $('start-screen').classList.remove('hidden'); });
$('mp-create').addEventListener('click', () => mpConnect('create'));
$('mp-join').addEventListener('click', () => mpConnect('join'));
$('mp-start').addEventListener('click', () => net.start());
$('mp-copy').addEventListener('click', async () => {
  const same = $('mp-server').value.trim() === location.host || $('mp-server').value.trim() === `${location.host}/mp`;
  const link = `${location.origin}${location.pathname}?room=${net.room}${same || !$('mp-server').value.trim() ? '' : '&server=' + encodeURIComponent($('mp-server').value.trim())}`;
  try { await navigator.clipboard.writeText(link); $('mp-copy').textContent = 'LINK COPIED ✓'; } catch (e) { prompt('Share this link:', link); }
  setTimeout(() => $('mp-copy').textContent = 'COPY INVITE LINK', 1800);
});
$('mp-code').addEventListener('input', e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z]/g, ''); });
{ let sn = '', ss = ''; try { sn = localStorage.getItem('sp_name') || ''; ss = localStorage.getItem('sp_server') || ''; } catch (e) { }
  $('mp-name').value = sn; $('mp-server').value = Q.get('server') || window.STRIKEPOINT_SERVER || (/^https?:$/.test(location.protocol) && location.host ? location.host : ss);
  const qr = Q.get('room'); if (qr) { $('mp-code').value = qr.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4); $('start-screen').classList.add('hidden'); $('mp-screen').classList.remove('hidden'); } }

// ---------------- boot ----------------
vm.visible = false;
await loadOp();
animate();
$('loading').style.display = 'none';
$('start').disabled = false; $('mp-open').disabled = false;
setQuality(quality);
if (Q.get('auto')) { resetGame(); }
window.__sp = { parts, cine, explode, playIntro, playOutro, heli, renderer, scene, director, nav, get state() { return { started, paused, health, ammo, kills, camMode, driving: !!driving, player, yaw, pitch, enemies: enemies.length, op: !!op }; }, set(o) { if ('yaw' in o) yaw = o.yaw; if ('pitch' in o) pitch = o.pitch; if ('x' in o) player.x = o.x; if ('z' in o) player.z = o.z; if (o.fire) { fireHeld = !!o.fire; } if (o.cam) { camMode = o.cam; } }, keys, vehicles, enemies, enterNear: toggleVehicle, shoot, resetGame, tick: dt => update(dt), world };
window.__mp = { vm, get fp() { return camMode === 'fp'; }, get driving() { return !!driving; }, gfx: { renderer, scene, sun, camera, setQuality: q => setQuality(q), get quality() { return quality; } }, connect: mpConnect, camera, scene, world, player, look: (y, p) => { yaw = y; pitch = p; }, get yaw() { return yaw; }, get pitch() { return pitch; }, get started() { return started && !paused; }, net, remotes, enemies, vehicles, get MP() { return MP; }, get host() { return mpHost; }, get kills() { return kills; }, get health() { return health; }, hurt: n => damagePlayer(n), enter: i => { if (i < 0) exitVehicle(); else enterVehicle(vehicles[i]); }, respawn: respawnLocal };
