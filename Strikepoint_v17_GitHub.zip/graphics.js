// Graphics upgrade: quality presets (AUTO/LOW/MEDIUM/HIGH/ULTRA), sky-lit reflections (environment map),
// sun glow, drifting dust, vignette and an optional FPS counter. Everything is guarded: if anything fails the game runs as before.
import * as THREE from 'three';
while (!window.__mp || !window.__mp.gfx) await new Promise(r => setTimeout(r, 50));
const G = window.__mp.gfx, { renderer, scene, camera } = G, $ = id => document.getElementById(id);
const LV = ['AUTO', 'LOW', 'MEDIUM', 'HIGH', 'ULTRA'], store = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { } }, load = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
let envTex = null, glow = null, dust = null, dustArr = null, vig = null, on = { env: false, fx: false };

function buildEnv() {
  const s = new THREE.Scene(), g = new THREE.SphereGeometry(50, 32, 16), pos = g.attributes.position, cols = new Float32Array(pos.count * 3);
  const hz = new THREE.Color(0xcfc6ae), zn = new THREE.Color(0x3f78bd), mid = new THREE.Color(0x9fbad2), gr = new THREE.Color(0x6a5538);
  for (let i = 0; i < pos.count; i++) { const y = pos.getY(i) / 50; const c = y < 0 ? hz.clone().lerp(gr, Math.min(1, -y * 1.4)) : y < .3 ? hz.clone().lerp(mid, y / .3) : mid.clone().lerp(zn, (y - .3) / .7); cols[i * 3] = c.r; cols[i * 3 + 1] = c.g; cols[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(cols, 3)); s.add(new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide })));
  const sm = new THREE.Mesh(new THREE.SphereGeometry(5, 16, 8), new THREE.MeshBasicMaterial({ color: new THREE.Color(1, .85, .6).multiplyScalar(6) })); sm.position.set(31, 20, 15); s.add(sm);
  const pm = new THREE.PMREMGenerator(renderer), rt = pm.fromScene(s, .02); pm.dispose(); g.dispose(); return rt.texture;
}
function dot(size, stops) { const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d'), h = size / 2, gr = x.createRadialGradient(h, h, 0, h, h, h); for (const [p, col] of stops) gr.addColorStop(p, col); x.fillStyle = gr; x.fillRect(0, 0, size, size); return new THREE.CanvasTexture(c); }
function ensureFx() {
  if (on.fx) return; on.fx = true;
  glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: dot(128, [[0, 'rgba(255,248,225,1)'], [.12, 'rgba(255,225,160,.75)'], [.4, 'rgba(255,190,110,.18)'], [1, 'rgba(255,170,90,0)']]), blending: THREE.AdditiveBlending, depthWrite: false, fog: false, transparent: true, opacity: .9 }));
  glow.scale.set(150, 150, 1); glow.frustumCulled = false; scene.add(glow);
  const N = 260, geo = new THREE.BufferGeometry(); dustArr = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) { dustArr[i * 3] = (Math.random() - .5) * 50; dustArr[i * 3 + 1] = Math.random() * 14; dustArr[i * 3 + 2] = (Math.random() - .5) * 50; }
  geo.setAttribute('position', new THREE.BufferAttribute(dustArr, 3));
  dust = new THREE.Points(geo, new THREE.PointsMaterial({ map: dot(32, [[0, 'rgba(255,255,255,1)'], [1, 'rgba(255,255,255,0)']]), size: .16, transparent: true, opacity: .32, depthWrite: false, color: 0xfff1d0, blending: THREE.AdditiveBlending }));
  dust.frustumCulled = false; scene.add(dust);
  vig = document.createElement('div'); vig.style.cssText = 'position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 58%,rgba(0,0,0,.36) 100%)';
  const gm = $('game'); gm ? gm.insertBefore(vig, renderer.domElement.nextSibling) : document.body.appendChild(vig);
}
function apply(q) {
  try {
    if (q >= 2 && !envTex) envTex = buildEnv();
    scene.environment = q >= 2 ? envTex : null; scene.environmentIntensity = .3;
    if (q >= 1) ensureFx();
    if (glow) { glow.visible = q >= 1; dust.visible = q >= 2; vig.style.display = q >= 1 ? 'block' : 'none'; }
  } catch (e) { console.warn('graphics upgrade skipped:', e); }
}
window.__gfx = { apply };

const lvl = () => { const s = load('sp_gfx'); return s === null || s === 'auto' ? -1 : +s; };   // -1 = AUTO
const clock = new THREE.Clock(), SUN = new THREE.Vector3(34, 22, 16).normalize(); let fpsOn = load('sp_fps') === '1', fpsEl = null, fa = 0, fn = 0;
(function loop() {
  requestAnimationFrame(loop); const dt = Math.min(.05, clock.getDelta());
  try {
    if (glow && glow.visible) glow.position.copy(camera.position).addScaledVector(SUN, 250);
    if (dust && dust.visible) { const cx = camera.position.x, cz = camera.position.z; for (let i = 0; i < dustArr.length; i += 3) { dustArr[i] += .35 * dt; dustArr[i + 1] += Math.sin(i + performance.now() / 2500) * .05 * dt; if (dustArr[i] - cx > 25) dustArr[i] -= 50; else if (dustArr[i] - cx < -25) dustArr[i] += 50; if (dustArr[i + 2] - cz > 25) dustArr[i + 2] -= 50; else if (dustArr[i + 2] - cz < -25) dustArr[i + 2] += 50; } dust.geometry.attributes.position.needsUpdate = true; }
    if (fpsOn && fpsEl) { fa += dt; fn++; if (fa > .5) { fpsEl.textContent = Math.round(fn / fa) + ' FPS · ' + LV[lvl() + 1] + (lvl() < 0 ? ' (now q' + G.quality + ')' : ''); fa = 0; fn = 0; } }
  } catch (e) { }
})();
function setLevel(l) {   // l: -1 AUTO, 0..3
  store('sp_gfx', l < 0 ? 'auto' : String(l)); window.__gfxLock = l >= 0; if (l >= 0) G.setQuality(l); else if (G.quality > 2) G.setQuality(2);
  const b = $('gfx-btn'); if (b) b.textContent = 'GRAPHICS: ' + LV[l + 1];
}
function setFps(v) { fpsOn = v; store('sp_fps', v ? '1' : '0'); if (!fpsEl) { fpsEl = document.createElement('div'); fpsEl.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:45;font:700 11px system-ui;color:#9fffa8;background:rgba(0,0,0,.5);padding:2px 6px;border-radius:4px;pointer-events:none'; document.body.appendChild(fpsEl); } fpsEl.style.display = v ? 'block' : 'none'; const b = $('fps-btn'); if (b) b.textContent = 'FPS COUNTER: ' + (v ? 'ON' : 'OFF'); }
const res = $('resume');
if (res) {
  const mk = (id, cls) => { const b = document.createElement('button'); b.id = id; b.className = cls; return b; };
  const gb = mk('gfx-btn', 'secondary'), fb = mk('fps-btn', 'secondary'); res.parentNode.insertBefore(gb, res.nextSibling); res.parentNode.insertBefore(fb, gb.nextSibling);
  gb.addEventListener('click', () => setLevel(lvl() >= 3 ? -1 : lvl() + 1)); fb.addEventListener('click', () => setFps(!fpsOn));
}
setLevel(lvl()); setFps(fpsOn); apply(G.quality);
